# 基金交易 App · 可交互原型

这是一个纯静态网页原型，无需安装依赖、无需构建。上传到 GitHub 并开启 GitHub Pages 后，即可获得一个稳定的公网访问链接。

![首页预览](preview.png)

## 文件说明

| 文件 | 说明 |
| --- | --- |
| `index.html` | 入口页面 |
| `styles.css` | 页面样式与响应式布局 |
| `app.js` | 数据、路由与全部交互逻辑 |
| `preview.png` | README 预览图，不参与应用运行 |
| `.nojekyll` | 告诉 GitHub Pages 不要使用 Jekyll 处理静态文件 |

> `index.html`、`styles.css`、`app.js` 必须放在仓库的**同一层级**，不要放进子文件夹。

---

## 方式一：网页上传（最简单）

1. 登录 GitHub，点击右上角 **+ → New repository**。
2. 填写仓库名，例如 `fund-app-demo`。
3. 可见性选择 **Public**（免费账号的 GitHub Pages 需要公开仓库）。
4. 创建仓库后，点击 **Add file → Upload files**。
5. 把本文件夹里的**所有文件**拖入上传区域，确保文件位于仓库根目录，而不是 `github-pages/` 子目录。
6. 点击 **Commit changes**。
7. 进入仓库的 **Settings → Pages**。
8. 在 **Build and deployment** 中：
   - Source 选择 **Deploy from a branch**
   - Branch 选择 **main**，目录选择 **/(root)**
   - 点击 **Save**
9. 等待约 1–3 分钟，刷新 Pages 设置页，会看到：

   ```text
   https://<你的用户名>.github.io/<仓库名>/
   ```

这个链接就是稳定访问地址。之后更新文件并提交到 `main` 分支，Pages 会自动重新发布。

### 如果仓库名是 `你的用户名.github.io`

例如用户名是 `alice`，仓库名是 `alice.github.io`，那么访问地址会变成：

```text
https://alice.github.io/
```

---

## 方式二：命令行上传

在 GitHub 新建一个空仓库后，在本地执行：

```bash
cd github-pages

git init
git add .
git commit -m "deploy interactive fund app prototype"
git branch -M main
git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git push -u origin main
```

然后按上面的方式，在 **Settings → Pages** 中选择 `main` 分支和 `/(root)` 目录发布。

如果使用 SSH，把远程地址换成：

```bash
git remote add origin git@github.com:<你的用户名>/<仓库名>.git
```

---

## 发布后检查

- 打开 `https://<用户名>.github.io/<仓库名>/`，确认首页正常显示。
- 如果样式丢失，检查 `styles.css`、`app.js` 是否和 `index.html` 在同一目录。
- 如果仍然看到旧版本，强制刷新浏览器或等待 GitHub Pages 的部署缓存更新。
- 页面使用哈希路由，例如：

  ```text
  https://<用户名>.github.io/<仓库名>/#/fund/fidelity-re
  ```

  分享深链接时请保留 `#/...` 部分。

## 说明

- 行情、净值、持仓和订单均为演示数据。
- 应用不依赖后端接口，所有状态保存在浏览器 `localStorage` 中。
- 若要绑定自定义域名，可在仓库 **Settings → Pages → Custom domain** 中配置。
