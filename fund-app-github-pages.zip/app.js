/* ============================================================
   基金交易 App 可交互原型
   Vanilla JS, no build step.
   ============================================================ */
(() => {
  "use strict";

  /* ----------------------------------------------------------
     Icons
     ---------------------------------------------------------- */
  const ICONS = {
    search:
      '<circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-4.2-4.2"/>',
    headset:
      '<path d="M4 13.2a8 8 0 0 1 16 0"/><path d="M4 13.5v2.6a2.4 2.4 0 0 0 2.4 2.4H8v-6H6.4A2.4 2.4 0 0 0 4 14.9Z"/><path d="M20 13.5v2.6a2.4 2.4 0 0 1-2.4 2.4H16v-6h1.6A2.4 2.4 0 0 1 20 14.9Z"/><path d="M17 19.5c0 1.1-.9 2-2 2h-1.5"/>',
    mail:
      '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    chevronLeft: '<path d="m15 18-6-6 6-6"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    chevronUp: '<path d="m18 15-6-6-6 6"/>',
    arrowUpRight: '<path d="M7 17 17 7"/><path d="M7 7h10v10"/>',
    arrowRight: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    arrowDown: '<path d="M12 4v15"/><path d="m6 13 6 6 6-6"/>',
    arrowUp: '<path d="M12 20V5"/><path d="m6 11 6-6 6 6"/>',
    eye:
      '<path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3.1"/>',
    eyeOff:
      '<path d="m3 3 18 18"/><path d="M10.6 6.1c.5-.1.9-.2 1.4-.2 6 0 9.5 6.1 9.5 6.1a16 16 0 0 1-2.4 3.1"/><path d="M6.2 6.8A16 16 0 0 0 2.5 12S6 18.1 12 18.1c1.5 0 2.8-.4 4-1"/><path d="M10.2 10.2a2.6 2.6 0 0 0 3.6 3.6"/>',
    more:
      '<circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
    deposit:
      '<path d="M12 3v10"/><path d="m8 9 4 4 4-4"/><path d="M4 16v3.2A1.8 1.8 0 0 0 5.8 21h12.4a1.8 1.8 0 0 0 1.8-1.8V16"/>',
    withdraw:
      '<path d="M12 14V4"/><path d="m8 8 4-4 4 4"/><path d="M4 16v3.2A1.8 1.8 0 0 0 5.8 21h12.4a1.8 1.8 0 0 0 1.8-1.8V16"/>',
    exchange:
      '<path d="M4 8h13"/><path d="m14 5 3 3-3 3"/><path d="M20 16H7"/><path d="m10 13-3 3 3 3"/>',
    orders:
      '<path d="M7 4h10a2 2 0 0 1 2 2v14l-3-1.6L13 20l-3-1.6L7 20V6a2 2 0 0 1 2-2Z"/><path d="M9.5 8h5M9.5 11.5h5"/>',
    fund:
      '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="m7.5 14 3-3 2.4 2.4 3.6-4.2"/><path d="M13.8 9.2h2.7v2.7"/>',
    structured:
      '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M7.5 15.5v-2.7M12 15.5V9M16.5 15.5V6.8"/>',
    publicFund:
      '<path d="M4 20h16"/><path d="M6 20V9.5h3V20"/><path d="M10.5 20V4h3v16"/><path d="M15 20v-7.2h3V20"/>',
    wallet:
      '<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18a2 2 0 0 1 2 2v11.5H6.5A2.5 2.5 0 0 1 4 16V7.5Z"/><path d="M4 8h14"/><path d="M15 12.5h5"/>',
    shield:
      '<path d="m12 3 7 2.8v5.6c0 4.3-2.8 7.6-7 9.6-4.2-2-7-5.3-7-9.6V5.8L12 3Z"/><path d="m8.8 11.7 2.1 2.1 4.4-4.5"/>',
    user:
      '<circle cx="12" cy="8" r="3.7"/><path d="M4.5 20c.8-3.6 3.8-5.6 7.5-5.6s6.7 2 7.5 5.6"/>',
    homeNav:
      '<circle cx="12" cy="12" r="8.7"/><path d="m12 6.8 5.2 5.2-5.2 5.2-5.2-5.2Z"/><path d="m12 10.4 1.6 1.6-1.6 1.6-1.6-1.6Z"/>',
    newsNav:
      '<rect x="4" y="4" width="16" height="16" rx="3.5"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    productNav:
      '<rect x="4" y="4" width="16" height="16" rx="3.5"/><path d="m8 14.5 2.7-3 2.2 2.2 3.3-3.9"/><path d="M13.8 9.8h2.4v2.4"/>',
    accountNav:
      '<circle cx="12" cy="12" r="8.7"/><path d="M7.5 10h7.7"/><path d="m13.3 7.8 2.2 2.2-2.2 2.2"/><path d="M16.5 14h-7.7"/><path d="m10.7 11.8-2.2 2.2 2.2 2.2"/>',
    personNav:
      '<circle cx="12" cy="8.2" r="3.4"/><path d="M5 20c.7-3.3 3.5-5.2 7-5.2s6.3 1.9 7 5.2"/>',
    filter:
      '<path d="M4 7h16M7 12h10M10 17h4"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    check: '<path d="m4.5 12.5 4.7 4.7L19.5 7"/>',
    share:
      '<path d="M14 4h6v6"/><path d="m20 4-9 9"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/>',
    heart:
      '<path d="M12 20s-7.7-4.6-7.7-10A4.3 4.3 0 0 1 12 7a4.3 4.3 0 0 1 7.7 3c0 5.4-7.7 10-7.7 10Z"/>',
    settings:
      '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
    help:
      '<circle cx="12" cy="12" r="9"/><path d="M9.6 9a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1.1.9-1.1 1.7"/><circle cx="12" cy="16.5" r=".8" fill="currentColor" stroke="none"/>',
    info:
      '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="7.8" r=".8" fill="currentColor" stroke="none"/>',
    calendar:
      '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M7.5 3v4M16.5 3v4M3.5 9h17"/>',
    clock:
      '<circle cx="12" cy="12" r="8.8"/><path d="M12 7.2v5l3.2 1.8"/>',
    lock:
      '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10"/>',
    backspace:
      '<path d="M9 5h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5-7 5-7Z"/><path d="m12 9 5 6M17 9l-5 6"/>',
    copy:
      '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    gift:
      '<rect x="4" y="9" width="16" height="11" rx="2"/><path d="M3 9h18v4H3zM12 9v11"/><path d="M12 9c-3.6 0-5-1.4-5-3a2 2 0 0 1 3.4-1.4C11.4 5.8 12 9 12 9Zm0 0c3.6 0 5-1.4 5-3a2 2 0 0 0-3.4-1.4C12.6 5.8 12 9 12 9Z"/>',
    star:
      '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
    activity:
      '<rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M7.5 3v4M16.5 3v4M3.5 9h17"/><path d="m8 14 2.7 2.4L16.5 11"/>',
    pie:
      '<path d="M12 3.2a8.8 8.8 0 1 0 8.8 8.8H12V3.2Z"/><path d="M15 3.6a8.7 8.7 0 0 1 5.4 5.4H15V3.6Z"/>',
    doc:
      '<path d="M6 3h8l4 4v14H6V3Z"/><path d="M14 3v5h4M9 12h6M9 16h6"/>',
    building:
      '<path d="M4 21V6l7-3v18M11 21h9V10l-9-4"/><path d="M7 9v1M7 13v1M7 17v1M15 12v1M15 16v1"/>',
    plus:
      '<path d="M12 5v14M5 12h14"/>',
    refresh:
      '<path d="M20 7v5h-5"/><path d="M4 17v-5h5"/><path d="M6.1 8.1A7 7 0 0 1 18.8 10"/><path d="M17.9 15.9A7 7 0 0 1 5.2 14"/>',
    logout:
      '<path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"/><path d="M9 16l-4-4 4-4"/><path d="M5 12h10"/>',
    alert:
      '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5"/><circle cx="12" cy="16.6" r=".9" fill="currentColor" stroke="none"/>',
    checkCircle:
      '<circle cx="12" cy="12" r="9"/><path d="m7.5 12.2 3 3 6-6.2"/>',
    trend:
      '<path d="m3 17 5-5 4 4 8-8"/><path d="M14 8h6v6"/>',
    spark:
      '<path d="m12 3 1.7 5.5L19 10l-5.3 1.5L12 17l-1.7-5.5L5 10l5.3-1.5L12 3Z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z"/>',
    target:
      '<circle cx="12" cy="12" r="8.7"/><circle cx="12" cy="12" r="4.8"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/>',
    card:
      '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 10h18M7 15h4"/>',
    new:
      '<path d="M12 3v4M12 17v4M3 12h4M17 12h4"/><circle cx="12" cy="12" r="4.2"/>',
  };

  function icon(name, cls = "") {
    return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`;
  }

  function statusbar() {
    return `<div class="statusbar" aria-hidden="true">
      <span class="statusbar-time">9:41</span>
      <div class="statusbar-icons">
        <svg viewBox="0 0 18 12" fill="currentColor"><rect x="0" y="7" width="3" height="5" rx="1"/><rect x="4.5" y="5" width="3" height="7" rx="1"/><rect x="9" y="2.5" width="3" height="9.5" rx="1"/><rect x="13.5" y="0" width="3" height="12" rx="1"/></svg>
        <svg viewBox="0 0 16 12" fill="currentColor"><path d="M8 11.6 5.2 8.7a4 4 0 0 1 5.6 0L8 11.6Zm-4.7-4.8a7 7 0 0 1 9.4 0l-1.4 1.4a5 5 0 0 0-6.6 0L3.3 6.8ZM.9 4.4a10.3 10.3 0 0 1 14.2 0l-1.4 1.4a8.3 8.3 0 0 0-11.4 0L.9 4.4Z"/></svg>
        <svg viewBox="0 0 27 13" fill="none"><rect x=".5" y=".5" width="22" height="12" rx="3.5" stroke="currentColor" opacity=".55"/><rect x="2" y="2" width="16.5" height="9" rx="2" fill="currentColor"/><path d="M24.2 4.2v4.6a2.4 2.4 0 0 0 0-4.6Z" fill="currentColor" opacity=".55"/></svg>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Data
     ---------------------------------------------------------- */
  const FUNDS = [
    {
      id: "fidelity-re",
      name: "富达金融地产基金",
      code: "HK0001",
      isin: "HK0001",
      currency: "HKD",
      type: "股票型",
      risk: "高风险",
      riskLevel: 5,
      tone: "green",
      badge: "富达",
      nav: 1.15144527,
      navDate: "2026-09-04",
      day: 7.73,
      y1: 5.25,
      min: 0,
      feeRate: 1.5,
      manager: "富达基金（香港）有限公司",
      inception: "2018-03-12",
      scale: "32.64 亿 HKD",
      tags: ["高风险", "HKD", "股票型", "精选"],
      desc: "主要投资于亚太区金融及房地产相关证券，把握利率周期与资产重估带来的长期机会。",
      note: "聚焦金融地产，港股仓位灵活",
      series: [1.19, 1.18, 1.185, 1.17, 1.155, 1.16, 1.14, 1.12, 1.09, 1.08, 1.06, 1.05, 1.07, 1.06, 1.04, 1.03, 1.045, 1.06, 1.075, 1.07, 1.085, 1.1, 1.09, 1.095, 1.08, 1.07, 1.06, 1.055, 1.04, 1.05, 1.06, 1.055, 1.065, 1.08, 1.075, 1.06, 1.05, 1.045, 1.055, 1.06, 1.04, 1.03, 1.02, 1.015, 1.03, 1.02, 1.0, 0.985, 0.99, 1.005, 1.02, 1.045, 1.04, 1.06, 1.07, 1.075, 1.06, 1.07, 1.1, 1.15144527],
      perf: [
        ["近1月", "+5.42%", "-2.18%"],
        ["近3月", "+1.11%", "-7.06%"],
        ["近6月", "+3.58%", "-9.33%"],
        ["今年以来", "+5.25%", "-12.41%"],
        ["近1年", "+5.25%", "-13.82%"],
        ["成立以来", "+15.14%", "-19.02%"],
      ],
      navHistory: [
        ["2026-09-04", "1.15144527", "+7.73%"],
        ["2026-09-03", "1.06886546", "-6.98%"],
        ["2026-09-02", "1.14909517", "+0.10%"],
        ["2026-09-01", "1.14794885", "-0.00%"],
        ["2026-08-31", "1.14797410", "+0.20%"],
        ["2026-08-28", "1.14571363", "+0.09%"],
      ],
    },
    {
      id: "xinfund",
      name: "稳健增长混合",
      code: "Z0000.FUND",
      isin: "33336666",
      currency: "HKD",
      type: "混合型",
      risk: "中风险",
      riskLevel: 3,
      tone: "gold",
      badge: "稳",
      nav: 83.0,
      navDate: "2026-09-14",
      day: 0.32,
      y1: 5.04,
      min: 1000,
      feeRate: 1.0,
      manager: "演示基金管理人",
      inception: "2021-06-18",
      scale: "18.72 亿 HKD",
      tags: ["中风险", "HKD", "混合型"],
      desc: "以多资产配置为核心，兼顾权益成长与固收打底，力争在可控波动下实现长期稳健增值。",
      note: "股债均衡配置，追求长期复利",
      series: [70, 70.4, 70.2, 71.1, 71.8, 71.5, 72.4, 73, 72.7, 73.5, 74.1, 73.9, 74.8, 75.2, 75, 75.9, 76.4, 76.1, 77, 77.8, 77.4, 78.1, 78.6, 78.2, 79, 79.6, 79.4, 80.1, 80.6, 80.2, 81, 81.5, 81.2, 82, 82.4, 82.1, 82.6, 82.9, 82.7, 83.0],
      perf: [
        ["近1月", "+1.33%", "-0.62%"],
        ["近3月", "+3.22%", "-1.48%"],
        ["近6月", "+4.66%", "-2.15%"],
        ["今年以来", "+5.04%", "-3.24%"],
        ["近1年", "+5.04%", "-4.08%"],
        ["成立以来", "+18.57%", "-8.91%"],
      ],
      navHistory: [
        ["2026-09-14", "83.00000000", "+0.32%"],
        ["2026-09-11", "82.73500000", "+0.15%"],
        ["2026-09-10", "82.61100000", "-0.08%"],
        ["2026-09-09", "82.67700000", "+0.21%"],
        ["2026-09-08", "82.50400000", "+0.34%"],
        ["2026-09-07", "82.22400000", "+0.12%"],
      ],
    },
    {
      id: "tech-growth",
      name: "环球科技成长基金",
      code: "HK6666",
      isin: "HK6666",
      currency: "HKD",
      type: "股票型",
      risk: "高风险",
      riskLevel: 5,
      tone: "navy",
      badge: "科技",
      nav: 23.9449,
      navDate: "2026-09-07",
      day: -0.74,
      y1: -9.99,
      min: 10000,
      feeRate: 1.5,
      manager: "演示基金管理人",
      inception: "2020-11-02",
      scale: "6.28 亿 HKD",
      tags: ["高风险", "HKD", "股票型", "私募"],
      desc: "投资全球范围内具备长期竞争力的科技与创新企业，覆盖人工智能、云计算与半导体产业链。",
      note: "聚焦全球科技龙头，波动较高",
      series: [32, 33, 32.4, 31.2, 30.8, 31.5, 32.7, 33.4, 32.2, 30.9, 29.6, 28.8, 29.4, 30.1, 31.2, 30.4, 29.2, 28.1, 27.6, 28.2, 27.4, 26.8, 27.5, 28.4, 27.9, 26.7, 25.9, 26.3, 25.2, 24.9, 25.7, 24.8, 24.1, 23.7, 24.3, 23.9, 23.2, 22.8, 23.4, 23.9449],
      perf: [
        ["近1月", "-2.18%", "-5.96%"],
        ["近3月", "-6.33%", "-10.12%"],
        ["近6月", "-11.42%", "-16.82%"],
        ["今年以来", "-9.99%", "-19.14%"],
        ["近1年", "-9.99%", "-24.62%"],
        ["成立以来", "-4.08%", "-31.27%"],
      ],
      navHistory: [
        ["2026-09-07", "23.9449", "-0.74%"],
        ["2026-09-04", "24.1244", "+0.85%"],
        ["2026-09-03", "23.9200", "-0.23%"],
        ["2026-09-02", "23.9743", "-0.82%"],
        ["2026-09-01", "24.1715", "-0.19%"],
        ["2026-08-31", "24.2168", "-0.25%"],
      ],
    },
    {
      id: "tk-money",
      name: "泰康开泰港元货币基金-A",
      code: "TKKT_HKD_MON_A",
      isin: "TKKT_HKD_MON_A",
      currency: "HKD",
      type: "货币型",
      risk: "低风险",
      riskLevel: 1,
      tone: "blue",
      badge: "泰康",
      nav: 11.5372,
      navDate: "2026-08-18",
      day: 0.01,
      y1: 1.92,
      min: 500,
      feeRate: 0,
      manager: "泰康资产管理（香港）有限公司",
      inception: "2019-09-20",
      scale: "54.21 亿 HKD",
      tags: ["低风险", "HKD", "货币型"],
      desc: "主要投资于短期存款及高流动性货币市场工具，适合作为现金管理与短期资金停泊工具。",
      note: "现金管理，流动性优先",
      series: [11.16, 11.17, 11.18, 11.19, 11.2, 11.21, 11.22, 11.235, 11.24, 11.25, 11.265, 11.28, 11.29, 11.3, 11.315, 11.33, 11.34, 11.355, 11.37, 11.38, 11.395, 11.41, 11.42, 11.435, 11.45, 11.46, 11.475, 11.49, 11.5, 11.5372],
      perf: [
        ["近1月", "+0.18%", "0.00%"],
        ["近3月", "+0.52%", "0.00%"],
        ["近6月", "+1.02%", "0.00%"],
        ["今年以来", "+1.47%", "0.00%"],
        ["近1年", "+1.92%", "0.00%"],
        ["成立以来", "+15.37%", "0.00%"],
      ],
      navHistory: [
        ["2026-08-18", "11.5372", "+0.01%"],
        ["2026-08-17", "11.5361", "+0.01%"],
        ["2026-08-14", "11.5350", "+0.01%"],
        ["2026-08-13", "11.5339", "+0.01%"],
        ["2026-08-12", "11.5328", "+0.01%"],
        ["2026-08-11", "11.5317", "+0.01%"],
      ],
    },
    {
      id: "global-infra",
      name: "全球核心基建投资基金II期",
      code: "GIF-II",
      isin: "GIF2026II",
      currency: "USD",
      type: "混合型",
      risk: "中高风险",
      riskLevel: 4,
      tone: "ink",
      badge: "基建",
      nav: 0,
      navDate: "—",
      day: 0,
      y1: null,
      min: 50000,
      feeRate: 1.0,
      manager: "演示另类投资管理人",
      inception: "2026-08-01",
      scale: "—",
      tags: ["中高风险", "USD", "混合型", "私募基金"],
      desc: "以全球核心基础设施资产为主要投资方向，覆盖能源转型、数字基建与交通物流等领域。",
      note: "长期封闭运作，聚焦实物资产",
      series: [],
      perf: [
        ["近1月", "—", "—"],
        ["近3月", "—", "—"],
        ["近6月", "—", "—"],
        ["今年以来", "—", "—"],
        ["近1年", "—", "—"],
        ["成立以来", "—", "—"],
      ],
      navHistory: [],
    },
    {
      id: "asia-income",
      name: "亚洲高股息收益基金",
      code: "HK8899",
      isin: "HK8899",
      currency: "HKD",
      type: "股票型",
      risk: "中风险",
      riskLevel: 3,
      tone: "red",
      badge: "红利",
      nav: 16.482,
      navDate: "2026-09-12",
      day: 0.66,
      y1: 8.74,
      min: 1000,
      feeRate: 1.2,
      manager: "演示基金管理人",
      inception: "2017-05-09",
      scale: "24.16 亿 HKD",
      tags: ["中风险", "HKD", "股票型"],
      desc: "精选亚洲市场现金流稳健、分红持续的高股息公司，追求收益与资本增值的平衡。",
      note: "高股息策略，季度审视",
      series: [14.2, 14.4, 14.35, 14.6, 14.8, 14.72, 15.0, 15.18, 15.1, 15.32, 15.4, 15.25, 15.5, 15.68, 15.6, 15.8, 15.9, 15.75, 16.0, 16.18, 16.1, 16.25, 16.38, 16.3, 16.42, 16.58, 16.48, 16.63, 16.78, 16.65, 16.5, 16.59, 16.482],
      perf: [
        ["近1月", "+1.72%", "-0.94%"],
        ["近3月", "+3.44%", "-2.06%"],
        ["近6月", "+6.18%", "-4.25%"],
        ["今年以来", "+8.74%", "-6.37%"],
        ["近1年", "+8.74%", "-7.12%"],
        ["成立以来", "+64.82%", "-24.61%"],
      ],
      navHistory: [
        ["2026-09-12", "16.4820", "+0.66%"],
        ["2026-09-11", "16.3740", "+0.28%"],
        ["2026-09-10", "16.3280", "-0.12%"],
        ["2026-09-09", "16.3480", "+0.41%"],
        ["2026-09-08", "16.2810", "+0.33%"],
        ["2026-09-07", "16.2270", "+0.19%"],
      ],
    },
  ];

  const FUND_MAP = Object.fromEntries(FUNDS.map((f) => [f.id, f]));

  const STRUCTURED = [
    {
      id: "eln-apple",
      name: "苹果看涨 ELN 结构化产品",
      code: "ELN20260807002",
      currency: "USD",
      annual: 3.11,
      strike: 70.0,
      knock: 70.0,
      term: 12,
      min: 500,
      issue: "2026-08-07",
      maturity: "2027-08-07",
      underlying: "APPLE",
      underlyingName: "Apple Inc.",
      tone: "ink",
      badge: "ELN",
      desc: "非保本浮动收益型结构化票据，收益与 Apple Inc.（AAPL）股价表现挂钩。若观察日股价不低于行使价，可提前敲出并获得年化票息。",
      note: "挂钩苹果，敲出价友好",
    },
    {
      id: "phoenix-usd",
      name: "美元凤凰添利系列2号结构化票据",
      code: "PHX20260902",
      currency: "USD",
      annual: 0.0,
      strike: 0.09,
      knock: 0.09,
      term: 6,
      min: 20000,
      issue: "2026-09-02",
      maturity: "2027-03-02",
      underlying: "多资产",
      underlyingName: "美元利率与信用组合",
      tone: "navy",
      badge: "凤凰",
      desc: "以美元利率与信用资产为底层，结合凤凰结构进行票息分配，适合具备一定风险识别能力的专业投资者。",
      note: "国泰君安定期现金流票据",
    },
  ];

  const STRUCTURED_MAP = Object.fromEntries(STRUCTURED.map((p) => [p.id, p]));

  const NEWS = [
    {
      id: "n1",
      time: "13:27",
      market: "港股",
      title: "高盛上调中生制药目标价至9.07港元，维持“买入”评级",
      summary:
        "高盛发表报告指出，中国生物制药宣布拟以现金44.8亿元，按约19倍过去12个月市盈率估值，增购附属公司正大天晴额外5%股权；交易完成后，其有效持股比例将由60%升至65%。",
      stock: "中国生物制药 +3.24%",
      body: [
        "高盛发表报告指出，中国生物制药宣布拟以现金44.8亿元，按约19倍过去12个月市盈率估值，增购附属公司正大天晴额外5%股权。交易完成后，其有效持股比例将由60%升至65%。",
        "管理层表示，该交易具策略吸引力，能够进一步提升公司在肿瘤、肝病等核心治疗领域的资源协同。高盛将公司目标价由8.30港元上调至9.07港元，维持“买入”评级。",
        "报告同时提示，带量采购政策变化、创新药研发进度及商业化不及预期，仍是公司中长期需要关注的主要风险。",
      ],
    },
    {
      id: "n2",
      time: "13:27",
      market: "港股",
      title: "交通银行股价创历史新高",
      summary:
        "交通银行(03328.HK)涨0.06%，报8.0950港元，股价创历史新高，总市值7153.05亿港元。",
      stock: "交通银行 +0.12%",
      body: [
        "交通银行(03328.HK)涨0.06%，报8.0950港元，股价创历史新高，总市值7153.05亿港元。",
        "市场人士认为，稳健的资产质量、持续的分红能力以及高股息资产配置需求，是近期银行板块获得资金青睐的重要原因。",
      ],
    },
    {
      id: "n3",
      time: "13:25",
      market: "港股",
      title: "渣打集团股价创历史新高",
      summary:
        "渣打集团（Standard Chartered，英国国际银行集团）股价于9月14日创下历史新高。截至当日，该股上涨1.32%，报245.0000港元，总市值达5344.50亿港元。",
      stock: "渣打集团 +1.41%",
      body: [
        "渣打集团股价于9月14日创下历史新高。截至当日，该股上涨1.32%，报245.0000港元，总市值达5344.50亿港元。",
        "公司近期持续回购股份，叠加市场对全球利率路径的重新定价，推动金融板块估值修复。",
      ],
    },
    {
      id: "n4",
      time: "09:32",
      market: "港股",
      title: "港股早报｜美联储降息预期升温，科技板块领涨",
      summary:
        "港股早盘高开，恒生科技指数涨幅居前。市场押注美联储年内进一步降息，成长股与高贝塔板块情绪明显回暖。",
      stock: "恒生科技指数 -0.04%",
      body: [
        "港股早盘高开，恒生科技指数涨幅居前。市场押注美联储年内进一步降息，成长股与高贝塔板块情绪明显回暖。",
        "盘面上，互联网平台、半导体及消费电子板块表现活跃；高股息与公用事业板块则出现小幅获利回吐。",
        "机构认为，短期市场仍将围绕流动性预期与盈利兑现展开，建议关注现金流稳健、估值合理的优质龙头。",
      ],
    },
    {
      id: "n5",
      time: "09:11",
      market: "美股",
      title: "美股收盘｜三大指数反弹，科技与能源板块受关注",
      summary:
        "美股三大指数集体收涨，纳指领涨。市场对通胀数据与降息路径的解读趋于乐观，AI算力链与能源股表现亮眼。",
      stock: "纳指100ETF +0.87%",
      body: [
        "美股三大指数集体收涨，纳指领涨。市场对通胀数据与降息路径的解读趋于乐观，AI算力链与能源股表现亮眼。",
        "资金流向显示，大型科技股仍是指数上行的主要贡献者，但市场宽度有所改善，中小盘成长股开始获得增量资金关注。",
      ],
    },
    {
      id: "n6",
      time: "08:50",
      market: "A股",
      title: "A股开盘｜沪指小幅高开，消费与医药走强",
      summary:
        "沪指小幅高开，创业板指震荡上行。消费、医药及高端制造板块涨幅居前，市场成交保持活跃。",
      stock: "沪深300 +0.42%",
      body: [
        "沪指小幅高开，创业板指震荡上行。消费、医药及高端制造板块涨幅居前，市场成交保持活跃。",
        "机构表示，随着中报披露结束，市场关注点将逐步转向景气度与盈利质量，建议均衡配置。",
      ],
    },
    {
      id: "n7",
      time: "08:30",
      market: "港股",
      title: "港股早报｜南向资金连续净流入，机构看好高股息资产",
      summary:
        "南向资金连续多个交易日净流入，银行、电信与公用事业板块获得增配。机构认为高股息资产仍具配置价值。",
      stock: "国企指数 +0.35%",
      body: [
        "南向资金连续多个交易日净流入，银行、电信与公用事业板块获得增配。机构认为高股息资产仍具配置价值。",
        "在低利率与资产荒背景下，稳定分红与现金流确定性成为资金配置的重要考量。",
      ],
    },
  ];

  const EMPTY_MARKET_NEWS = [
    {
      id: "cal1",
      time: "20:30",
      market: "美股",
      title: "美国 8 月 CPI 同比数据",
      summary: "市场预期 2.9%，前值 3.1%。数据公布后或将影响美联储降息路径。",
      tag: "宏观数据",
    },
    {
      id: "cal2",
      time: "次日 02:00",
      market: "美股",
      title: "美联储 FOMC 利率决议",
      summary: "市场普遍预期维持利率不变，重点关注点阵图与主席新闻发布会。",
      tag: "央行会议",
    },
    {
      id: "cal3",
      time: "10:00",
      market: "A股",
      title: "中国 8 月社会消费品零售总额",
      summary: "关注消费修复斜率及服务消费表现。",
      tag: "宏观数据",
    },
  ];

  const MARKET_DATA = {
    hk: {
      title: "港股",
      indices: [
        {
          id: "hsi",
          name: "恒生指数",
          code: "HSI",
          price: 24879.56,
          chg: 0.3,
          chgAbs: 73.93,
          series: [24600, 24720, 24650, 24790, 24820, 24760, 24840, 24890, 24830, 24910, 24879],
          market: "港股",
          desc: "恒生指数是香港股票市场最具代表性的蓝筹股指数，覆盖金融、资讯科技、地产及公用事业等核心行业。",
        },
        {
          id: "hcei",
          name: "国企指数",
          code: "HSCEI",
          price: 8274.81,
          chg: 0.35,
          chgAbs: 28.48,
          series: [8180, 8210, 8190, 8240, 8230, 8260, 8250, 8280, 8270, 8290, 8274],
          market: "港股",
          desc: "恒生中国企业指数追踪在香港上市的中国内地企业表现，是观察中资股行情的重要基准。",
        },
        {
          id: "hstech",
          name: "恒生科技指数",
          code: "HSTECH",
          price: 4318.99,
          chg: -0.04,
          chgAbs: -1.58,
          series: [4340, 4360, 4350, 4330, 4345, 4320, 4310, 4335, 4305, 4328, 4318],
          market: "港股",
          desc: "恒生科技指数覆盖香港上市的最大科技企业，反映互联网、云计算、半导体与智能硬件板块表现。",
        },
      ],
      tools: [
        ["港股 ETF", "publicFund"],
        ["区间涨跌幅", "trend"],
        ["创业板", "activity"],
        ["港股 ADR", "building"],
        ["新股认购", "new"],
      ],
      industries: [
        ["生命科学工具和服务", "+3.97%", "泰格医药", "+6.52%"],
        ["电脑与外围设备", "+3.17%", "联想控股", "+5.35%"],
        ["容器与包装", "+3.06%", "锦胜集团", "+11.11%"],
        ["食品与主要用品零售", "+2.46%", "鸣鸣很忙", "+6.38%"],
        ["消费信贷", "+2.34%", "METROPOLIS CAP", "+22.86%"],
      ],
      listTitle: "全部港股",
      movers: [
        { id: "jihui", name: "吉辉控股股权", code: "08580.HK", price: 0.025, chg: 56.25, market: "港股", series: [0.015, 0.016, 0.018, 0.017, 0.021, 0.02, 0.024, 0.025] },
        { id: "zhongzi", name: "中资国际控股", code: "08118.HK", price: 0.087, chg: 52.63, market: "港股", series: [0.05, 0.055, 0.052, 0.06, 0.071, 0.068, 0.081, 0.087] },
        { id: "haiqing", name: "海清智元", code: "01392.HK", price: 28.02, chg: 48.19, market: "港股", series: [18, 19.2, 20.1, 21.5, 24, 23.2, 26.4, 28.02] },
        { id: "junzhi", name: "俊知集团", code: "01300.HK", price: 2.955, chg: 45.93, market: "港股", series: [1.9, 2.05, 2.0, 2.21, 2.44, 2.6, 2.82, 2.955] },
        { id: "huihao", name: "汇景控股", code: "09968.HK", price: 0.084, chg: 35.48, market: "港股", series: [0.06, 0.062, 0.061, 0.068, 0.072, 0.078, 0.08, 0.084] },
      ],
    },
    us: {
      title: "美股",
      indices: [
        {
          id: "spx",
          name: "标普500 ETF",
          code: "SPY.US",
          price: 764.29,
          chg: 0.85,
          chgAbs: 6.46,
          series: [752, 756, 754, 758, 760, 757, 762, 761, 764, 763, 764.29],
          market: "美股",
          desc: "SPDR 标普500 ETF 追踪标普500指数，覆盖美国大型上市公司，是全球最具流动性的 ETF 之一。",
        },
        {
          id: "qqq",
          name: "纳指100 ETF",
          code: "QQQ.US",
          price: 714.88,
          chg: 0.87,
          chgAbs: 6.19,
          series: [698, 702, 700, 707, 705, 710, 708, 712, 711, 714, 714.88],
          market: "美股",
          desc: "追踪纳斯达克100指数，集中于美国非金融领域的创新型大型企业。",
        },
        {
          id: "dia",
          name: "道指 ETF",
          code: "DIA.US",
          price: 525.79,
          chg: 0.97,
          chgAbs: 5.04,
          series: [515, 517, 516, 520, 519, 522, 521, 524, 523, 525, 525.79],
          market: "美股",
          desc: "追踪道琼斯工业平均指数，覆盖美国最具代表性的蓝筹企业。",
        },
      ],
      tools: [
        ["美股 ETF", "publicFund"],
        ["盘前盘后榜", "trend"],
        ["新股认购", "new"],
        ["选股器", "target"],
        ["财报日历", "calendar"],
      ],
      industries: [
        ["电子设备、仪器和元件", "+4.06%", "高频电子", "+42.40%"],
        ["建筑与工程", "+3.83%", "Nocera", "+19.89%"],
        ["通信设备", "+3.71%", "奥科", "+6.42%"],
        ["电气设备", "+3.45%", "Vicor电子", "+11.15%"],
        ["航空公司和航空服务", "+2.00%", "联合大陆航空", "+3.13%"],
      ],
      listTitle: "全部美股",
      movers: [
        { id: "biodx", name: "Biodesixa Pharmaceuticals", code: "BDRX.US", price: 1.3, chg: 96.94, market: "美股", series: [0.5, 0.55, 0.63, 0.72, 0.86, 1.02, 1.3] },
        { id: "trug", name: "TruGolf", code: "TRUG.US", price: 0.653, chg: 76.14, market: "美股", series: [0.3, 0.34, 0.38, 0.42, 0.5, 0.57, 0.653] },
        { id: "mkdw", name: "MKDWELL Tech", code: "MKDW.US", price: 7.75, chg: 51.96, market: "美股", series: [4.1, 4.5, 5.0, 4.8, 5.9, 6.5, 7.75] },
        { id: "acv", name: "ACV Auctions", code: "ACVA.US", price: 10.41, chg: 44.18, market: "美股", series: [6.8, 7.1, 7.8, 8.4, 8.1, 9.3, 10.41] },
      ],
    },
    cn: {
      title: "沪深",
      indices: [
        {
          id: "shcomp",
          name: "上证指数",
          code: "000001.SH",
          price: 3881.83,
          chg: 0.16,
          chgAbs: 6.28,
          series: [3858, 3865, 3860, 3872, 3876, 3870, 3878, 3884, 3879, 3880, 3881],
          market: "沪深",
          desc: "上证综合指数反映上海证券交易所全部上市股票的整体表现。",
        },
        {
          id: "szcomp",
          name: "深证成指",
          code: "399001.SZ",
          price: 13360.9,
          chg: 0.82,
          chgAbs: 108.78,
          series: [13120, 13200, 13180, 13260, 13240, 13300, 13290, 13340, 13320, 13350, 13360],
          market: "沪深",
          desc: "深证成份指数覆盖深交所具有代表性的上市公司。",
        },
        {
          id: "chinext",
          name: "创业板指",
          code: "399006.SZ",
          price: 3281.9,
          chg: 1.21,
          chgAbs: 39.18,
          series: [3200, 3230, 3215, 3245, 3225, 3260, 3240, 3275, 3260, 3278, 3281],
          market: "沪深",
          desc: "创业板指数聚焦成长型创新创业企业。",
        },
      ],
      tools: [
        ["区间涨跌幅", "trend"],
        ["热门 ETF", "publicFund"],
        ["选股器", "target"],
        ["新股日历", "calendar"],
        ["财报日历", "doc"],
      ],
      industries: [
        ["半导体", "+3.88%", "中芯国际", "+7.22%"],
        ["消费电子", "+2.91%", "立讯精密", "+5.18%"],
        ["创新药", "+2.56%", "恒瑞医药", "+4.73%"],
        ["新能源设备", "+1.84%", "宁德时代", "+3.33%"],
        ["食品饮料", "+1.42%", "贵州茅台", "+1.90%"],
      ],
      listTitle: "A 股涨幅榜",
      movers: [
        { id: "smic", name: "中芯国际", code: "688981.SH", price: 105.6, chg: 7.22, market: "沪深", series: [92, 94, 93, 97, 99, 98, 102, 105.6] },
        { id: "luxshare", name: "立讯精密", code: "002475.SZ", price: 46.8, chg: 5.18, market: "沪深", series: [42, 42.6, 42.2, 43.4, 44.0, 43.8, 45.4, 46.8] },
        { id: "hengrui", name: "恒瑞医药", code: "600276.SH", price: 63.9, chg: 4.73, market: "沪深", series: [57, 58.2, 57.8, 59.4, 60.6, 60.1, 62.4, 63.9] },
        { id: "catl", name: "宁德时代", code: "300750.SZ", price: 296.2, chg: 3.33, market: "沪深", series: [270, 273, 272, 280, 283, 281, 290, 296.2] },
      ],
    },
  };

  const HOT_SEARCHES = ["富达金融地产", "货币基金", "科技成长", "ELN", "高股息"];
  const DEFAULT_RECENT = ["富达金融地产基金", "港元货币基金", "苹果 ELN"];

  const RISK_QUESTIONS = [
    {
      q: "您的投资经验大约有多久？",
      options: ["少于 1 年", "1–3 年", "3–5 年", "5 年以上"],
    },
    {
      q: "您能够接受的最大本金亏损幅度是？",
      options: ["几乎不能接受亏损", "不超过 5%", "不超过 15%", "可以接受 20% 以上"],
    },
    {
      q: "这笔资金预计的投资期限是？",
      options: ["3 个月以内", "3–12 个月", "1–3 年", "3 年以上"],
    },
    {
      q: "当投资短期下跌 10%，您通常会？",
      options: ["立即全部卖出", "卖出一部分", "继续持有观望", "逢低追加投资"],
    },
  ];

  const ROOT_TABS = [
    { name: "home", label: "首页", icon: "homeNav", path: "#/home" },
    { name: "news", label: "资讯", icon: "newsNav", path: "#/news" },
    { name: "products", label: "产品", icon: "productNav", path: "#/products" },
    { name: "account", label: "账户", icon: "accountNav", path: "#/account" },
    { name: "mine", label: "我的", icon: "personNav", path: "#/mine" },
  ];

  const PRODUCT_TABS = [
    { id: "watch", label: "自选" },
    { id: "private", label: "私募基金" },
    { id: "structured", label: "结构化产品" },
    { id: "public", label: "公募基金" },
    { id: "hk", label: "港股" },
    { id: "us", label: "美股" },
    { id: "cn", label: "沪深" },
  ];

  const NEWS_TABS = ["快讯", "要闻", "看美股", "看中国", "日历", "自选"];

  /* ----------------------------------------------------------
     State helpers
     ---------------------------------------------------------- */
  const STORAGE_KEY = "xinjia-fund-prototype-v1";

  const DEFAULT_STATE = {
    hideAmounts: false,
    watchlist: ["fidelity-re", "tech-growth"],
    holdings: [{ fundId: "xinfund", shares: 1659, cost: 79.02 }],
    orders: [
      {
        id: "ord-demo-1",
        fundId: "xinfund",
        name: "稳健增长混合",
        code: "Z0000.FUND",
        type: "申购",
        status: "已下单待确认",
        amount: 10000,
        fee: 0,
        date: "2026-08-19 16:43:42",
        orderNo: "20260814FUND0000000002",
        shares: 0,
      },
      {
        id: "ord-demo-2",
        fundId: "fidelity-re",
        name: "富达金融地产基金",
        code: "HK0001",
        type: "申购",
        status: "已下单待确认",
        amount: 1000,
        fee: 0,
        date: "2026-08-19 13:24:36",
        orderNo: "20260814FUND0000000001",
        shares: 0,
      },
    ],
    productsTab: "public",
    newsTab: "快讯",
    newsFilter: "港股",
    fundDetailTab: "trend",
    fundPeriod: "1y",
    accountTab: "holdings",
    openGroups: { hk: true, cn: false, us: false, fund: true, bond: false },
    fundFilter: { type: "all", risk: "all", min: "all" },
    orderFilter: { fund: "all", type: "all" },
    searchQuery: "",
    recentSearches: DEFAULT_RECENT.slice(),
    risk: { started: false, step: 0, answers: [], done: false },
    deposit: { step: 1, currency: "HKD", amount: "", bank: "hsbc" },
    withdraw: { currency: "HKD", amount: "" },
    exchange: { from: "HKD", to: "CNY", amount: "" },
    isProfessional: true,
    successData: null,
  };

  function cloneDefault() {
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return cloneDefault();
      const saved = JSON.parse(raw);
      const base = cloneDefault();
      return {
        ...base,
        ...saved,
        fundFilter: { ...base.fundFilter, ...(saved.fundFilter || {}) },
        orderFilter: { ...base.orderFilter, ...(saved.orderFilter || {}) },
        openGroups: { ...base.openGroups, ...(saved.openGroups || {}) },
        risk: { ...base.risk, ...(saved.risk || {}) },
        deposit: { ...base.deposit, ...(saved.deposit || {}) },
        withdraw: { ...base.withdraw, ...(saved.withdraw || {}) },
        exchange: { ...base.exchange, ...(saved.exchange || {}) },
        successData: null,
        searchQuery: "",
      };
    } catch {
      return cloneDefault();
    }
  }

  let state = loadState();
  let pendingPinAction = null;

  function saveState() {
    try {
      const persist = {
        hideAmounts: state.hideAmounts,
        watchlist: state.watchlist,
        holdings: state.holdings,
        orders: state.orders,
        productsTab: state.productsTab,
        newsTab: state.newsTab,
        newsFilter: state.newsFilter,
        fundFilter: state.fundFilter,
        orderFilter: state.orderFilter,
        openGroups: state.openGroups,
        risk: state.risk,
        deposit: state.deposit,
        withdraw: state.withdraw,
        exchange: state.exchange,
        isProfessional: state.isProfessional,
        recentSearches: state.recentSearches,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(persist));
    } catch {
      /* storage may be unavailable in some preview contexts */
    }
  }

  function parseRoute() {
    const raw = (location.hash || "#/home").replace(/^#\/?/, "");
    const [pathPart, queryPart] = raw.split("?");
    const segments = pathPart.split("/").filter(Boolean);
    const route = {
      name: segments[0] || "home",
      id: segments[1] ? decodeURIComponent(segments[1]) : null,
      query: Object.fromEntries(new URLSearchParams(queryPart || "")),
    };
    return route;
  }

  /* ----------------------------------------------------------
     Utility functions
     ---------------------------------------------------------- */
  function esc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function money(n, digits = 2) {
    if (n == null || Number.isNaN(Number(n))) return "—";
    return Number(n).toLocaleString("en-US", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits,
    });
  }

  function signedPct(n, digits = 2) {
    if (n == null || Number.isNaN(Number(n))) return "—";
    const num = Number(n);
    return `${num > 0 ? "+" : ""}${num.toFixed(digits)}%`;
  }

  function signClass(n) {
    if (n == null || Number(n) === 0) return "muted";
    return Number(n) > 0 ? "up" : "down";
  }

  function maskMoney(n, digits = 2) {
    return state.hideAmounts ? "••••••" : money(n, digits);
  }

  function nowText() {
    const d = new Date();
    const pad = (x) => String(x).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function makeOrderNo(prefix = "FUND") {
    const d = new Date();
    const pad = (x) => String(x).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${prefix}${String(Date.now()).slice(-10)}`;
  }

  function getFund(id) {
    return FUND_MAP[id] || null;
  }

  function getHolding(fundId) {
    return state.holdings.find((h) => h.fundId === fundId) || null;
  }

  function holdingValue(h) {
    const fund = getFund(h.fundId);
    return fund ? h.shares * fund.nav : 0;
  }

  function holdingProfit(h) {
    return h.shares * ((getFund(h.fundId)?.nav || 0) - h.cost);
  }

  function getStock(id) {
    for (const key of Object.keys(MARKET_DATA)) {
      const market = MARKET_DATA[key];
      const hit = [...market.indices, ...market.movers].find((s) => s.id === id);
      if (hit) return hit;
    }
    return null;
  }

  function getProduct(id) {
    return FUND_MAP[id] || STRUCTURED_MAP[id] || null;
  }

  function isStructured(id) {
    return Boolean(STRUCTURED_MAP[id]);
  }

  function routeKey(route) {
    return `${route.name}/${route.id || ""}/${JSON.stringify(route.query || {})}`;
  }

  let routeStack = [parseRoute()];

  function navigate(path, opts = {}) {
    if (!path) return;
    const hash = path.startsWith("#") ? path : `#/${path}`;
    if (location.hash === hash) {
      render();
      return;
    }
    if (opts.replace) {
      routeStack = [{ ...parseRoute() }];
      try { history.replaceState({ depth: 1 }, "", hash); routeStack = [{ ...parseRoute() }]; }
      catch { location.hash = hash; }
    } else {
      routeStack.push({ ...parseRoute() });
      try { history.pushState({ depth: routeStack.length }, "", hash); }
      catch { location.hash = hash; }
    }
    state.route = parseRoute();
    render();
  }

  function goBack() {
    if (routeStack.length > 1) {
      history.back();
    } else {
      navigate("#/home", { replace: true });
    }
  }

  function goProducts(tab) {
    if (tab) state.productsTab = tab;
    if (parseRoute().name === "products") {
      render();
    } else {
      navigate("#/products");
    }
  }

  function showToast(message) {
    const appEl = document.getElementById("app");
    if (!appEl) return;
    appEl.querySelectorAll(".toast").forEach((el) => el.remove());
    const el = document.createElement("div");
    el.className = "toast";
    el.textContent = message;
    appEl.appendChild(el);
    setTimeout(() => el.remove(), 2100);
  }

  function toggleWatch(id) {
    const i = state.watchlist.indexOf(id);
    const added = i < 0;
    if (added) {
      state.watchlist.push(id);
    } else {
      state.watchlist.splice(i, 1);
    }
    saveState();
    render();
    showToast(added ? "已加入自选" : "已取消自选");
  }

  function pickSeries(fund, period) {
    const base = fund.series && fund.series.length ? fund.series : [1, 1, 1, 1];
    const count = { "1m": 12, "3m": 24, "6m": 36, "1y": 48, all: base.length }[period] || 48;
    return base.slice(Math.max(0, base.length - count));
  }

  function periodLabels(period) {
    return {
      "1m": ["08-15", "08-23", "09-01", "09-09", "09-14"],
      "3m": ["06-16", "07-15", "08-13", "09-01", "09-14"],
      "6m": ["03-16", "05-18", "07-16", "08-28", "09-14"],
      "1y": ["2025-09", "2026-01", "2026-05", "2026-09"],
      all: ["成立", "2022", "2024", "2026"],
    }[period] || [];
  }

  function chartGeometry(data, width = 340, height = 150, padX = 8, padY = 14) {
    const min = Math.min(...data);
    const max = Math.max(...data);
    const span = max - min || 1;
    const pts = data.map((v, i) => {
      const x = padX + (i * (width - padX * 2)) / Math.max(1, data.length - 1);
      const y = padY + (1 - (v - min) / span) * (height - padY * 2);
      return [x, y];
    });
    const line = pts
      .map((pt, i) => `${i === 0 ? "M" : "L"}${pt[0].toFixed(2)} ${pt[1].toFixed(2)}`)
      .join(" ");
    const area = `${line} L${width - padX} ${height} L${padX} ${height} Z`;
    return { line, area, pts, min, max };
  }

  let chartUid = 0;

  function sparkline(data, color = "#0c9f6e", className = "spark") {
    if (!data || !data.length) return "";
    const w = 100;
    const h = 28;
    const g = chartGeometry(data, w, h, 1, 4);
    const id = `sp-${++chartUid}`;
    return `<svg class="${className}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".16"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
      <path d="${g.area}" fill="url(#${id})"/>
      <path d="${g.line}" fill="none" stroke="${color}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>
    </svg>`;
  }

  function bigChart(data, color = "#c8942b", showAxis = true) {
    if (!data || !data.length) {
      return `<div class="chart-empty">暂无净值走势数据</div>`;
    }
    const w = 360;
    const h = 154;
    const g = chartGeometry(data, w, h, 8, 12);
    const id = `big-${++chartUid}`;
    const grid = [0.2, 0.48, 0.76].map((r) => {
      const y = h * r;
      return `<line x1="8" y1="${y}" x2="${w - 8}" y2="${y}" stroke="#eef1f4" stroke-width="1" stroke-dasharray="2 4"/>`;
    }).join("");
    const last = g.pts[g.pts.length - 1];
    const maxLabel = "";
    const minLabel = "";
    return `<svg class="big-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".2"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
      ${grid}
      <path d="${g.area}" fill="url(#${id})"/>
      <path d="${g.line}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
      <line x1="${last[0] - 16}" y1="${last[1]}" x2="${w - 8}" y2="${last[1]}" stroke="${color}" stroke-width=".7" stroke-dasharray="2 3" opacity=".45"/>
      <circle cx="${last[0]}" cy="${last[1]}" r="3.2" fill="#fff" stroke="${color}" stroke-width="2"/>
      ${maxLabel}${minLabel}
    </svg>`;
  }

  /* ----------------------------------------------------------
     Shared components
     ---------------------------------------------------------- */
  function topbar(title, opts = {}) {
    const { sticky = true, support = true } = opts;
    return `<header class="topbar ${sticky ? "topbar--sticky" : ""}">
      <div class="brand-name">${title}${opts.en ? `<small>${opts.en}</small>` : ""}</div>
      <div class="top-actions">
        ${support ? `<button class="icon-btn" data-action="toast" data-msg="在线客服 9:00–18:00" aria-label="客服">${icon("headset")}</button>` : ""}
        <button class="icon-btn" data-action="open-search" aria-label="搜索">${icon("search")}</button>
        <button class="icon-btn" data-action="open-mail" aria-label="消息"><span class="dot"></span>${icon("mail")}</button>
      </div>
    </header>`;
  }

  function detailBar(title, right = "", opts = {}) {
    const { white = false } = opts;
    return `<header class="detail-bar ${white ? "detail-bar--white" : ""}">
      <button class="back" data-action="back" aria-label="返回">${icon("chevronLeft")}</button>
      <div class="detail-title">${title}</div>
      ${right || `<span style="width:40px"></span>`}
    </header>`;
  }

  function bottomNav(active) {
    return `<nav class="bottom-nav">${ROOT_TABS.map(
      (t) => `<button class="nav-item ${t.name === active ? "is-active" : ""}" data-nav="${t.path}" aria-label="${t.label}">
        <span class="nav-symbol">${icon(t.icon)}</span>
        <span>${t.label}</span>
      </button>`
    ).join("")}</nav>`;
  }

  function fundBadge(fund, small = false) {
    return `<span class="fund-badge fund-badge--${fund.tone || "gold"}" ${small ? 'style="width:30px;height:30px;border-radius:8px;font-size:11px"' : ""}>${esc(fund.badge || fund.name.slice(0, 1))}</span>`;
  }

  function tag(text, tone = "") {
    return `<span class="tag ${tone ? `tag--${tone}` : ""}">${esc(text)}</span>`;
  }

  function sectionHead(title, linkText = "", linkPath = "", count = "") {
    return `<div class="section-head">
      <h2>${title}${count ? `<span>${count}</span>` : ""}</h2>
      ${linkText ? `<button class="section-link" data-nav="${linkPath}">${linkText}${icon("chevronRight")}</button>` : ""}
    </div>`;
  }

  function fundCard(fund, opts = {}) {
    const watched = state.watchlist.includes(fund.id);
    return `<article class="home-product" data-nav="#/fund/${fund.id}">
      <div class="product-head">
        ${fundBadge(fund)}
        <div class="product-title">
          <h3>${esc(fund.name)}</h3>
          <p><span class="product-code">${esc(fund.code)}</span>${tag(fund.currency)}${tag(fund.type)}${tag(fund.risk)}</p>
        </div>
        <button class="watch-btn ${watched ? "is-on" : ""}" data-action="toggle-watch" data-id="${fund.id}" aria-label="自选">${icon("heart")}</button>
      </div>
      <div class="product-metrics">
        <div class="metric"><strong class="${signClass(fund.y1)}">${signedPct(fund.y1)}</strong><span>近一年涨跌幅</span></div>
        <div class="metric"><strong>${fund.nav ? money(fund.nav, 4) : "—"}</strong><span>最新净值</span></div>
        <div class="metric"><strong>${fund.min ? money(fund.min, 0) : "0"}</strong><span>起购金额 ${fund.currency}</span></div>
      </div>
      <div class="product-foot">
        <span class="product-note"><i></i>${esc(fund.note || "长期配置价值")}</span>
        <button class="btn btn-sm btn--soft" data-action="open-buy" data-id="${fund.id}">申购</button>
      </div>
    </article>`;
  }

  function compactFundRow(fund) {
    return `<button class="fund-row" data-nav="#/fund/${fund.id}" style="width:100%;text-align:left">
      ${fundBadge(fund, true)}
      <div class="product-title">
        <h3>${esc(fund.name)}</h3>
        <p><span class="product-code">${esc(fund.code)}</span>${tag(fund.currency)}${tag(fund.risk)}</p>
      </div>
      <div class="row-return">
        <strong class="${signClass(fund.y1)}">${signedPct(fund.y1)}</strong>
        <span>近一年</span>
      </div>
      <span class="product-arrow">${icon("chevronRight")}</span>
    </button>`;
  }

  function structuredCard(p) {
    return `<article class="structured-card" data-nav="#/structured/${p.id}">
      <div class="top">
        <div>
          <h3>${esc(p.name)}</h3>
          <div class="code">${esc(p.code)}</div>
        </div>
        ${tag(p.currency, "gold")}
      </div>
      <div class="structured-metrics">
        <div><strong class="${p.annual > 0 ? "up" : ""}">${p.annual.toFixed(2)}%</strong><span>年化票息</span></div>
        <div><strong>${p.strike}%</strong><span>行使价</span></div>
        <div><strong>${p.knock}%</strong><span>敲出界限</span></div>
        <div><strong>${p.term}</strong><span>期限（月）</span></div>
      </div>
      <div class="product-foot">
        <span class="product-note"><i></i>${esc(p.note)}</span>
        <span class="tag">${esc(p.underlying)}</span>
      </div>
    </article>`;
  }

  function emptyState(iconName, title, text) {
    return `<div class="product-empty">
      <div class="empty-icon">${icon(iconName)}</div>
      <h3>${title}</h3><p>${text}</p>
    </div>`;
  }

  function stepper(current) {
    const labels = ["选择方式", "资金汇入", "提交凭证", "完成"];
    return `<div class="stepper">${labels.map((label, i) => {
      const n = i + 1;
      return `<div class="step ${n === current ? "is-active" : ""} ${n < current ? "is-done" : ""}"><i>${n < current ? "✓" : n}</i><span>${label}</span></div>`;
    }).join("")}</div>`;
  }

  /* ----------------------------------------------------------
     Home page
     ---------------------------------------------------------- */
  function pageHome() {
    const total = 5162601.66;
    const today = 28799.93;
    const marketValue = 5157101.28;
    return `<div class="page page--with-nav">
      ${topbar("首页")}
      <div class="content">
        <section class="overview-card">
          <div class="ov-top">
            <span class="ov-label">总资产 · 港币 ${icon("chevronDown")}</span>
            <button class="ov-link" data-nav="#/analysis">资产分析 ${icon("chevronRight")}</button>
          </div>
          <div class="ov-value">${maskMoney(total)}<span class="currency">HKD</span></div>
          <div class="ov-foot">
            <div class="ov-foot-item"><span>今日盈亏</span><strong class="${today >= 0 ? "up" : "down"}">${state.hideAmounts ? "••••" : `+${money(today)}`}</strong></div>
            <div class="ov-foot-item"><span>持仓市值</span><strong>${maskMoney(marketValue)}</strong></div>
          </div>
        </section>

        <section class="hero-quick">
          <button class="quick-item" data-action="go-products" data-tab="private"><span class="quick-icon">${icon("fund")}</span><span>私募基金</span></button>
          <button class="quick-item" data-action="go-products" data-tab="structured"><span class="quick-icon">${icon("structured")}</span><span>结构化产品</span></button>
          <button class="quick-item" data-action="go-products" data-tab="public"><span class="quick-icon">${icon("publicFund")}</span><span>公募基金</span></button>
          <button class="quick-item" data-nav="#/deposit"><span class="quick-icon">${icon("deposit")}</span><span>存入资金</span></button>
          <button class="quick-item" data-nav="#/all"><span class="quick-icon quick-icon--plain">${icon("more")}</span><span>更多</span></button>
        </section>

        <div class="promo" data-nav="#/professional" role="button" tabindex="0" style="width:100%;text-align:left">
          <svg class="promo-skyline" viewBox="0 0 320 120" fill="none" aria-hidden="true">
            <path d="M0 120V97h24V86h14v11h18V76h22v44h16V63h10v57h18V82h25v38h17V71h14v49h20V94h18v26h19V56h12v64h20V88h18v32h15V72h22v48h20V84h16v36Z" fill="rgba(9,25,44,.44)"/>
            <path d="M42 86V78h3v8M94 63v-8h3v8M168 82v-7h3v7M243 71v-9h3v9M273 56v-9h3v9" stroke="rgba(255,255,255,.4)" stroke-width="1.2"/>
            <path d="M8 120V106h9v14M28 120v-8h7v8M62 120v-18h8v18M112 120v-11h7v11M140 120v-22h8v22M191 120v-10h6v10M230 120v-16h7v16M265 120v-9h7v9M298 120v-13h7v13" fill="rgba(11,27,48,.56)"/>
            <circle cx="276" cy="27" r="15" fill="rgba(255,222,158,.18)"/>
          </svg>
          <div class="promo-kicker">PRIVATE WEALTH · GLOBAL ALLOCATION</div>
          <h3>看见世界<br/>也看见长期</h3>
          <p>全球资产配置 · 专业投资视角</p>
          <span class="promo-cta">了解专业投资者服务 ${icon("arrowRight")}</span>
          <div class="promo-dots"><i class="on"></i><i></i><i></i></div>
        </div>

        <section class="section-card">
          ${sectionHead("精选基金", "查看全部", "#/products", "6")}
          ${fundCard(FUND_MAP["fidelity-re"])}
          ${fundCard(FUND_MAP["xinfund"])}
        </section>

        <section class="section-card">
          ${sectionHead("结构化产品", "查看全部", "#/products?tab=structured", "2")}
          ${structuredCard(STRUCTURED[0])}
        </section>

        <section class="section-card" style="padding-bottom:10px">
          ${sectionHead("市场速览", "更多行情", "#/products?tab=hk")}
          ${MARKET_DATA.hk.indices.map((idx) => `<button class="fund-row" data-nav="#/stock/${idx.id}" style="width:100%;text-align:left">
            <div class="product-title"><h3>${idx.name}</h3><p><span class="product-code">${idx.code}</span><span>${idx.market} · 延时</span></p></div>
            <div style="width:63px">${sparkline(idx.series, idx.chg >= 0 ? "#0c9f6e" : "#df5361")}</div>
            <div class="row-return"><strong class="${signClass(idx.chg)}">${money(idx.price)}</strong><span class="${signClass(idx.chg)}">${signedPct(idx.chg)}</span></div>
            <span class="product-arrow">${icon("chevronRight")}</span>
          </button>`).join("")}
        </section>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     News
     ---------------------------------------------------------- */
  function pageNews() {
    const active = state.newsTab;
    let tabFilter = state.newsFilter;
    if (active === "看美股") tabFilter = "美股";
    if (active === "看中国") tabFilter = "A股";
    if (active === "自选") tabFilter = "港股";
    let list;
    if (active === "日历") {
      list = EMPTY_MARKET_NEWS;
    } else {
      list = NEWS.filter((n) => (active === "要闻" ? true : n.market === tabFilter));
    }
    return `<div class="page page--with-nav">
      ${topbar("资讯")}
      <div class="news-tabs">${NEWS_TABS.map((t) => `<button class="news-tab ${t === active ? "is-active" : ""}" data-action="news-tab" data-tab="${t}">${t}</button>`).join("")}</div>
      ${active === "快讯" ? `<div class="news-filter-row">
        <span class="news-date">今天</span>
        ${["港股", "美股", "A股"].map((f) => `<button class="chip ${tabFilter === f ? "chip--active" : ""}" data-action="news-filter" data-filter="${f}">${f}</button>`).join("")}
      </div>` : `<div style="height:2px"></div>`}
      <div class="news-feed">
        ${list.map((n) => active === "日历" ? calendarRow(n) : newsItem(n)).join("")}
      </div>
      <div class="news-more">— 已经看到今日全部资讯 —</div>
    </div>`;
  }

  function newsItem(n) {
    return `<article class="news-item" data-nav="#/news/${n.id}">
      <div class="news-rail"><span class="news-dot"></span></div>
      <div class="news-main">
        <div class="news-meta"><span>${n.time}</span><span class="share">${icon("share")}分享</span></div>
        <h3>${esc(n.title)}</h3>
        <p>${esc(n.summary)}</p>
        ${n.stock ? `<span class="news-stock">${esc(n.stock)}</span>` : ""}
      </div>
    </article>`;
  }

  function calendarRow(n) {
    return `<div class="calendar-row">
      <div class="cal-time">${esc(n.time)}</div>
      <div class="cal-dot"></div>
      <div class="cal-main"><span class="tag tag--gold">${esc(n.tag)}</span><h3>${esc(n.title)}</h3><p>${esc(n.summary)}</p></div>
    </div>`;
  }

  function pageNewsDetail(route) {
    const n = NEWS.find((x) => x.id === route.id) || NEWS[0];
    const relatedFund = n.id === "n1" ? FUND_MAP["asia-income"] : n.id === "n5" ? FUND_MAP["tech-growth"] : FUND_MAP["xinfund"];
    return `<div class="page">
      ${detailBar("资讯详情", `<button class="detail-action" data-action="toast" data-msg="已复制分享链接">${icon("share")}</button>`)}
      <div class="article-cover">
        <span>${n.market} · 快讯</span>
        <h2>${esc(n.title)}</h2>
      </div>
      <div class="article-body">
        <div class="article-meta"><span>市场资讯</span><span>2026-09-14 ${n.time}</span><span>3 分钟阅读</span></div>
        <p class="lead">${esc(n.summary)}</p>
        ${n.body.slice(1).map((para, i) => i === 0 ? `<div class="article-quote">${esc(para)}</div>` : `<p>${esc(para)}</p>`).join("")}
        ${n.stock ? `<div class="article-stock-card"><strong>${esc(n.stock.split(" ")[0])}</strong><span>${esc(n.stock.split(" ")[1] || "")}</span></div>` : ""}
        <p>以上内容根据公开资料整理，仅供信息参考，不构成任何投资建议。市场有风险，投资需谨慎。</p>
      </div>
      <div class="article-footer">本文由研究院编辑整理 · 数据来源于公开市场信息</div>
      <div style="margin:0 16px 18px">
        <div class="section-card" style="box-shadow:none;border:1px solid var(--line)">
          ${sectionHead("相关基金", "查看详情", `#/fund/${relatedFund.id}`)}
          ${compactFundRow(relatedFund)}
        </div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Products
     ---------------------------------------------------------- */
  function pageProducts(route) {
    if (route.query && route.query.tab && PRODUCT_TABS.some((t) => t.id === route.query.tab)) {
      state.productsTab = route.query.tab;
      saveState();
      // Consume the shortcut query so subsequent tab switches are not overridden.
      try {
        history.replaceState({ depth: Math.max(1, routeStack.length) }, "", "#/products");
      } catch {
        /* noop */
      }
    }
    const tab = state.productsTab || "public";
    return `<div class="page page--with-nav">
      ${topbar("财富")}
      <div class="product-tabs">${PRODUCT_TABS.map((t) => `<button class="product-tab ${t.id === tab ? "is-active" : ""}" data-action="product-tab" data-tab="${t.id}">${t.label}</button>`).join("")}</div>
      ${renderProductBody(tab)}
    </div>`;
  }

  function renderProductBody(tab) {
    if (["public", "private", "watch"].includes(tab)) {
      if (tab === "watch") return renderWatchlist();
      const filters = `<div class="filter-row">
        ${filterButton("基金类型", state.fundFilter.type === "all" ? "全部" : state.fundFilter.type, "type")}
        ${filterButton("风险等级", state.fundFilter.risk === "all" ? "全部" : state.fundFilter.risk, "risk")}
        ${filterButton("起投金额", state.fundFilter.min === "all" ? "全部" : state.fundFilter.min, "min")}
      </div>`;
      let list = tab === "private" ? FUNDS.filter((f) => f.tags.includes("私募") || f.tags.includes("私募基金")) : FUNDS;
      list = applyFundFilters(list);
      if (tab === "private") {
        return `<div class="page-section">${filters}
          <div class="section-caption" style="padding-left:16px">${list.length} 只私募产品 · 仅向专业投资者开放</div>
          ${list.map((f) => privateFundCard(f)).join("") || emptyState("fund", "暂无匹配产品", "调整筛选条件后再试")}
        </div>`;
      }
      return `<div class="page-section">${filters}
        <div class="fund-list">
          <div class="fund-list-head"><span>名称 / 代码</span><span>最新净值</span><span>涨跌幅</span></div>
          ${list.map((f) => `<button class="fund-list-row" data-nav="#/fund/${f.id}" style="width:100%;text-align:left">
            <div class="fund-list-name"><strong>${esc(f.name)}</strong><p>${tag(f.currency)}<span class="product-code">${esc(f.code)}</span></p></div>
            <div class="fund-list-num">${f.nav ? money(f.nav, 4) : "—"}<span>${esc(f.navDate)}</span></div>
            <div class="fund-list-num ${signClass(f.y1)}">${signedPct(f.y1)}<span>近一年</span></div>
          </button>`).join("") || `<div style="padding:30px;text-align:center;color:var(--muted);font-size:11px">暂无匹配基金</div>`}
        </div>
        <div class="section-caption" style="text-align:center;padding:16px">数据更新于 2026-09-14 · 历史业绩不代表未来表现</div>
      </div>`;
    }
    if (tab === "structured") {
      return `<div class="cont" style="padding-top:2px">
        <div class="structured-card" style="margin-top:0">${`<div class="section-head" style="margin:0 0 10px"><h2>结构化产品<span>2</span></h2><span class="tag tag--gold">专业投资者</span></div>`}</div>
        ${STRUCTURED.map((p) => structuredCard(p)).join("")}
        <div class="section-card" style="margin:0 16px;box-shadow:none;border:1px solid var(--line)">
          <div class="product-note" style="font-size:10px;line-height:1.8">结构化产品为非保本浮动收益产品，收益与挂钩标的表现相关。请仔细阅读产品说明书及风险揭示书。</div>
        </div>
      </div>`;
    }
    const market = MARKET_DATA[tab];
    if (!market) return emptyState("trend", "暂不支持该市场", "请选择其他市场查看");
    return `<div class="page-section" style="padding-top:2px">
      <div class="indices-strip">
        ${market.indices.map((idx) => `<button class="index-mini" data-nav="#/stock/${idx.id}" style="text-align:left">
          <div class="name">${esc(idx.name)}<span>${idx.market === "美股" ? "US" : "延时"}</span></div>
          <div class="val ${signClass(idx.chg)}">${money(idx.price)}</div>
          <div class="chg ${signClass(idx.chg)}">${signedPct(idx.chg)}</div>
          ${sparkline(idx.series, idx.chg >= 0 ? "#0c9f6e" : "#df5361")}
        </button>`).join("")}
      </div>
      <div class="market-tools">
        ${market.tools.map(([label, ic]) => `<button class="quick-item" data-action="toast" data-msg="${label} · 演示入口"><span class="quick-icon">${icon(ic)}</span><span>${label}</span></button>`).join("")}
      </div>
      <section class="market-section">
        ${sectionHead("热门行业", "全部行业", "")}
        ${market.industries.map((x) => `<div class="mover-row">
          <div><div class="mover-name">${x[0]}</div><div class="small up" style="margin-top:3px">${x[1]}</div></div>
          <div class="mover-price"><strong>${x[2]}</strong><span class="up">${x[3]}</span></div>
        </div>`).join("")}
      </section>
      <section class="market-section">
        ${sectionHead(market.listTitle, "查看更多", "")}
        ${market.movers.map((s) => `<button class="mover-row" data-nav="#/stock/${s.id}" style="width:100%;text-align:left">
          <div><div class="mover-name">${esc(s.name)}<span class="code">${esc(s.code)}</span></div><div class="small muted" style="margin-top:3px">${s.market} · 延时</div></div>
          <div style="width:54px">${sparkline(s.series, s.chg >= 0 ? "#0c9f6e" : "#df5361")}</div>
          <div class="mover-price"><strong>${money(s.price, s.price < 1 ? 3 : 2)}</strong><span class="up">${signedPct(s.chg)}</span></div>
        </button>`).join("")}
      </section>
      <div class="section-caption" style="text-align:center;padding:14px">行情数据由演示数据提供 · 延迟至少 15 分钟</div>
    </div>`;
  }

  function filterButton(label, value, key) {
    return `<button class="filter-select" data-action="filter" data-key="${key}">${label}:${value}${icon("chevronDown")}</button>`;
  }

  function applyFundFilters(list) {
    return list.filter((f) => {
      if (state.fundFilter.type !== "all" && f.type !== state.fundFilter.type) return false;
      if (state.fundFilter.risk !== "all" && f.risk !== state.fundFilter.risk) return false;
      if (state.fundFilter.min !== "all") {
        const limit = { "1000": 1000, "10000": 10000, "50000": 50000 }[state.fundFilter.min] || 0;
        if (f.min > limit) return false;
      }
      return true;
    });
  }

  function privateFundCard(f) {
    return `<article class="structured-card" data-nav="#/fund/${f.id}">
      <div class="top"><div><h3>${esc(f.name)}</h3><div class="code">${esc(f.code)}</div></div>${tag("私募", "gold")}</div>
      <div class="structured-metrics">
        <div><strong class="${signClass(f.y1)}">${signedPct(f.y1)}</strong><span>近一年涨跌幅</span></div>
        <div><strong>${f.min ? money(f.min, 0) : "0"}</strong><span>首次申购 (${f.currency})</span></div>
        <div><strong>${f.nav ? money(f.nav, 2) : "—"}</strong><span>最新净值</span></div>
      </div>
      <div class="product-foot"><span class="product-note"><i></i>${esc(f.note)}</span><span class="tag">${esc(f.risk)}</span></div>
    </article>`;
  }

  function renderWatchlist() {
    const items = state.watchlist.map(getFund).filter(Boolean);
    const stocks = state.watchlist.map(getStock).filter(Boolean);
    const count = items.length + stocks.length;
    return `<div class="page-section" style="padding-top:2px">
      <div class="watchlist-hint">
        <div class="hint-icon">${icon("heart")}</div>
        <div><strong>我的自选</strong><p>已收藏 ${count} 只产品，点击查看详情</p></div>
      </div>
      ${items.length ? `<div class="fund-list" style="margin-top:12px">
        <div class="fund-list-head"><span>名称 / 代码</span><span>最新净值</span><span>涨跌幅</span></div>
        ${items.map((f) => `<button class="fund-list-row" data-nav="#/fund/${f.id}" style="width:100%;text-align:left">
          <div class="fund-list-name"><strong>${esc(f.name)}</strong><p>${tag(f.currency)}<span class="product-code">${esc(f.code)}</span></p></div>
          <div class="fund-list-num">${f.nav ? money(f.nav, 4) : "—"}<span>${esc(f.navDate)}</span></div>
          <div class="fund-list-num ${signClass(f.y1)}">${signedPct(f.y1)}<span>近一年</span></div>
        </button>`).join("")}
      </div>` : ""}
      ${stocks.length ? `<section class="market-section" style="margin-top:12px">
        <div class="section-head"><h2 style="font-size:14px">行情自选</h2><span class="tag">延时</span></div>
        ${stocks.map((s) => `<button class="mover-row" data-nav="#/stock/${s.id}" style="width:100%;text-align:left">
          <div><div class="mover-name">${esc(s.name)}<span class="code">${esc(s.code)}</span></div><div class="small muted" style="margin-top:3px">${esc(s.market)}</div></div>
          <div class="mover-price"><strong>${money(s.price, s.price < 1 ? 3 : 2)}</strong><span class="${signClass(s.chg)}">${signedPct(s.chg)}</span></div>
        </button>`).join("")}
      </section>` : ""}
      ${!count ? emptyState("heart", "还没有自选产品", "在基金或行情详情页点击心形图标即可加入自选") : ""}
    </div>`;
  }

  /* ----------------------------------------------------------
     Account
     ---------------------------------------------------------- */
  function pageAccount() {
    const isHoldings = state.accountTab === "holdings";
    const fundHolding = state.holdings[0] || null;
    const fund = fundHolding ? getFund(fundHolding.fundId) : null;
    const todayPrefix = nowText().slice(0, 10);
    const todayOrders = state.orders.filter((o) => o.date.startsWith(todayPrefix));
    return `<div class="page page--with-nav">
      ${topbar("账户")}
      <div class="account-top">
        <div class="account-kicker"><strong>现金账户</strong><span style="font-family:monospace">C10002286</span><span class="virtual-pill">虚拟资产</span></div>
      </div>
      <section class="asset-hero">
        <div class="asset-hero-top">
          <span class="asset-hero-label">资产净值 · 港币 ${icon("chevronDown")}
            <button class="hero-eye" data-action="toggle-amount" aria-label="显示或隐藏金额">${icon(state.hideAmounts ? "eyeOff" : "eye")}</button>
          </span>
          <button class="asset-analysis-link" data-nav="#/analysis">资产分析 ${icon("chevronRight")}</button>
        </div>
        <div class="hero-value">${state.hideAmounts ? "••••••••" : "5,162,601.66"}</div>
        <div class="asset-metrics">
          <div class="asset-metric"><span>证券市值 ${icon("chevronDown")}</span><strong>${maskMoney(5006090.6)}</strong></div>
          <div class="asset-metric"><span>现金余额 ${icon("chevronDown")}</span><strong>${maskMoney(4851219.28)}</strong></div>
          <div class="asset-metric"><span>持仓盈亏</span><strong class="light">${state.hideAmounts ? "••••" : "-1,040,396.62"}</strong></div>
          <div class="asset-metric"><span>今日盈亏</span><strong class="light">${state.hideAmounts ? "••••" : "+31,199.93"}</strong></div>
          <div class="asset-metric"><span>可用最大购买力</span><strong>${maskMoney(4722719.28)}</strong></div>
          <div class="asset-metric"><span>冻结资金</span><strong>${maskMoney(128500)}</strong></div>
        </div>
      </section>

      <section class="quick-grid">
        <button class="quick-item" data-nav="#/products"><span class="quick-icon">${icon("exchange")}</span><span>交易</span></button>
        <button class="quick-item" data-nav="#/orders"><span class="quick-icon">${icon("orders")}</span><span>全部订单</span></button>
        <button class="quick-item" data-nav="#/deposit"><span class="quick-icon">${icon("deposit")}</span><span>存入资金</span></button>
        <button class="quick-item" data-nav="#/withdraw"><span class="quick-icon">${icon("withdraw")}</span><span>提取资金</span></button>
        <button class="quick-item" data-nav="#/exchange"><span class="quick-icon">${icon("exchange")}</span><span>货币兑换</span></button>
        <button class="quick-item" data-nav="#/orders"><span class="quick-icon">${icon("doc")}</span><span>资金记录</span></button>
        <button class="quick-item" data-action="toast" data-msg="暂无正在认购的新股"><span class="quick-icon">${icon("new")}</span><span>新股认购</span></button>
        <button class="quick-item" data-nav="#/professional"><span class="quick-icon">${icon("star")}</span><span>专业投资者</span></button>
        <button class="quick-item" data-nav="#/risk"><span class="quick-icon">${icon("shield")}</span><span>风险测评</span></button>
        <button class="quick-item" data-nav="#/all"><span class="quick-icon quick-icon--plain">${icon("more")}</span><span>更多</span></button>
      </section>

      <div class="account-tabs">
        <button class="${isHoldings ? "is-active" : ""}" data-action="account-tab" data-tab="holdings">持仓<span class="count">(${2 + state.holdings.length})</span></button>
        <button class="${!isHoldings ? "is-active" : ""}" data-action="account-tab" data-tab="orders">今日订单<span class="count">(${todayOrders.length})</span></button>
        <button class="edit-hold" data-action="toast" data-msg="持仓管理 · 演示入口" aria-label="持仓管理">${icon("settings")}</button>
      </div>

      ${isHoldings ? `<div class="account-groups">
        ${accountGroup("hk", "flag--hk", "港股账户", "(2)", "净资产（港币）", "3,447,651.50", "+31,199.93", "-1,033,203.23", `
          <div class="holding-table">
            <div class="holding-row holding-row--head"><div>名称代码</div><div class="cell">市值 / 数量</div><div class="cell">现价 / 成本</div><div class="cell">今日盈亏</div></div>
            <div class="holding-row"><div class="name">腾讯控股<p>00700.HK <span class="tag">延</span></p></div><div class="cell">3,434,976.50<span>7,962 股</span></div><div class="cell">431.400<span>517.50</span></div><div class="cell up">+31,199.93<span class="up">+0.61%</span></div></div>
            <div class="holding-row"><div class="name">顺丰房托<p>02191.HK <span class="tag">延</span></p></div><div class="cell">12,675.00<span>5,000 股</span></div><div class="cell">2.535<span>3.18</span></div><div class="cell down">-75.00<span class="down">-0.59%</span></div></div>
          </div>`)}
        ${accountGroup("cn", "flag--cn", "A股通账户", "(0)", "净资产（人民币）", "1,389,226.50", "0.00", "0.00", `<div class="empty-hold">暂无持仓</div>`, true)}
        ${accountGroup("us", "flag--us", "美股账户", "(0)", "净资产（美元）", "188,026.00", "0.00", "0.00", `<div class="empty-hold">暂无持仓</div>`, true)}
        ${accountGroup("fund", "flag--fund", "基金账户", `(${state.holdings.length})`, "净资产（港币）", fundHolding ? money(holdingValue(fundHolding)) : "0.00", fundHolding ? `+${money(holdingProfit(fundHolding))}` : "0.00", fundHolding ? `+${money(holdingProfit(fundHolding))}` : "0.00", fundHolding ? `
          <div class="holding-table">
            <div class="holding-row holding-row--head"><div>基金名称</div><div class="cell">市值 / 份额</div><div class="cell">净值 / 成本</div><div class="cell">持仓盈亏</div></div>
            <div class="holding-row"><div class="name">${esc(fund.name)}<p>${esc(fund.code)} ${tag("HKD", "gold")}</p></div><div class="cell">${maskMoney(holdingValue(fundHolding))}<span>${money(fundHolding.shares, 0)} 份</span></div><div class="cell">${money(fund.nav, 2)}<span>${money(fundHolding.cost, 2)}</span></div><div class="cell up">+${money(holdingProfit(fundHolding))}<span class="up">+5.04%</span></div></div>
          </div>
          <button class="btn btn-sm btn--ghost" style="width:100%;margin-top:10px" data-nav="#/holdings">查看基金持仓</button>` : `<div class="empty-hold">暂无基金持仓</div>`)}
        ${accountGroup("bond", "flag--bond", "债券", "(0)", "净资产（港币）", "0.00", "0.00", "0.00", `<div class="empty-hold">暂无持仓</div>`, true)}
        <div class="account-footer-note">行情数据由演示数据提供 · 仅作界面演示</div>
      </div>` : todayOrders.length ? `<div>${todayOrders.map((o) => orderCard(o)).join("")}</div><div class="news-more">— 已展示今日全部订单 —</div>` : `<div class="order-empty">
        <div class="empty-icon">${icon("orders")}</div>
        <h3>暂无今日订单</h3><p>今天还没有新的交易委托</p>
      </div>`}
    </div>`;
  }

  function accountGroup(key, flagClass, title, count, label, total, today, pnl, body, collapsedDefault = false) {
    const open = state.openGroups[key] ?? !collapsedDefault;
    return `<section class="account-group ${open ? "" : "is-collapsed"}">
      <div class="account-group-head" data-action="toggle-group" data-key="${key}">
        <span class="flag ${flagClass}">${{ "flag--hk": "港", "flag--cn": "A", "flag--us": "US", "flag--fund": "基", "flag--bond": "债" }[flagClass] || ""}</span>
        <h3>${title}</h3><span class="extra">${count}</span>
        <span class="chev">${icon("chevronDown")}</span>
      </div>
      <div class="group-body">
        <div class="group-summary">
          <div><div class="sum-label">${label}</div><div class="sum-val">${maskMoney(total.replace(/,/g, ""))}</div></div>
          <div class="group-pnl"><div><span>今日盈亏</span><strong class="${today.startsWith("-") ? "down" : "up"}">${state.hideAmounts ? "••••" : today}</strong></div><div><span>持仓盈亏</span><strong class="${pnl.startsWith("-") ? "down" : pnl === "0.00" ? "muted" : "up"}">${state.hideAmounts ? "••••" : pnl}</strong></div></div>
        </div>
        ${body}
      </div>
    </section>`;
  }

  /* ----------------------------------------------------------
     Mine
     ---------------------------------------------------------- */
  function pageMine() {
    const riskLabel = state.risk.done ? getRiskResult().name : "未测评";
    return `<div class="page page--with-nav">
      ${topbar("我的")}
      <section class="profile-card">
        <div class="avatar">${icon("user")}</div>
        <div class="profile-info"><h2>156****1227</h2><div class="profile-tags">${tag("HK", "gold")}<span class="small muted" style="align-self:center">延时</span>${tag("US", "gold")}<span class="small muted" style="align-self:center">延时</span></div></div>
        <button class="profile-edit" data-action="toast" data-msg="账户资料 · 演示入口">${icon("settings")}</button>
      </section>
      <section class="mine-section">
        <h3>服务</h3>
        ${mineRow("账户与安全", "shield", "账户与安全 · 演示入口")}
        ${mineRow("我的行情", "trend", "我的行情 · 演示入口")}
        ${mineRow("活动中心", "activity", "活动中心 · 暂无新活动")}
        ${mineRow("奖励中心", "gift", "奖励中心 · 暂无可用奖励")}
        ${mineRow("风险测评", "doc", "", "#/risk", riskLabel)}
        ${mineRow("设置", "settings", "设置 · 演示入口")}
        ${mineRow("功能建议", "info", "感谢反馈，我们会认真阅读")}
        ${mineRow("帮助中心", "help", "在线帮助 9:00–18:00")}
        ${mineRow("产品说明", "info", "基金交易原型 v1.0")}
      </section>
      <div class="mine-actions">
        <button class="mine-action" data-action="toast" data-msg="切换账号 · 演示入口">切换账号</button>
        <button class="mine-action mine-action--danger" data-action="toast" data-msg="已退出登录（演示）">退出登录</button>
        <button class="mine-action" data-action="reset-demo" style="color:#a4abb6;font-size:11px">重置演示数据</button>
      </div>
      <div class="section-caption" style="text-align:center;padding:18px 20px">投资有风险 · 本页面为产品原型演示，不构成投资建议</div>
    </div>`;
  }

  function mineRow(label, iconName, msg, path = "", badge = "") {
    return `<button class="mine-row" ${path ? `data-nav="${path}"` : `data-action="toast" data-msg="${msg}"`}>
      <span class="mine-icon">${icon(iconName)}</span><span>${label}</span>
      ${badge ? `<span class="mine-badge">${badge}</span>` : ""}
      <span class="mine-chev">${icon("chevronRight")}</span>
    </button>`;
  }

  /* ----------------------------------------------------------
     All functions
     ---------------------------------------------------------- */
  function pageAll() {
    const groups = [
      {
        title: "常用功能",
        items: [
          ["私募基金", "fund", "go-products", "private"],
          ["结构化产品", "structured", "go-products", "structured"],
          ["公募基金", "publicFund", "go-products", "public"],
          ["存入资金", "deposit", "nav", "#/deposit"],
        ],
      },
      {
        title: "财富",
        items: [
          ["私募基金", "fund", "go-products", "private"],
          ["结构化产品", "structured", "go-products", "structured"],
          ["公募基金", "publicFund", "go-products", "public"],
          ["现金管理", "wallet", "toast", "现金管理 · 演示入口"],
        ],
      },
      {
        title: "资金",
        items: [
          ["存入资金", "deposit", "nav", "#/deposit"],
          ["提取资金", "withdraw", "nav", "#/withdraw"],
          ["货币兑换", "exchange", "nav", "#/exchange"],
          ["资金记录", "doc", "nav", "#/orders"],
        ],
      },
      {
        title: "账户",
        items: [
          ["风险测评", "doc", "nav", "#/risk"],
          ["专业投资者", "star", "nav", "#/professional"],
          ["资产分析", "pie", "nav", "#/analysis"],
          ["全部订单", "orders", "nav", "#/orders"],
        ],
      },
      {
        title: "行情工具",
        items: [
          ["新股中心", "new", "toast", "新股中心 · 演示入口"],
          ["选股器", "target", "toast", "选股器 · 演示入口"],
          ["市场行情", "trend", "nav", "#/products"],
          ["帮助中心", "help", "toast", "在线帮助 9:00–18:00"],
        ],
      },
    ];
    return `<div class="page">
      ${detailBar("全部功能", `<button class="detail-action detail-action--gold" data-action="toast" data-msg="编辑模式 · 演示入口">编辑</button>`)}
      <div style="padding-top:2px">
        ${groups.map((g) => `<section class="fn-section"><h3>${g.title}</h3><div class="fn-grid">
          ${g.items.map(([label, ic, type, value]) => `<button class="fn-item" ${type === "nav" ? `data-nav="${value}"` : type === "go-products" ? `data-action="go-products" data-tab="${value}"` : `data-action="toast" data-msg="${value}"`}>
            <span class="quick-icon">${icon(ic)}</span><span>${label}</span>
          </button>`).join("")}
        </div></section>`).join("")}
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Fund detail
     ---------------------------------------------------------- */
  function pageFund(route) {
    const fund = getFund(route.id) || FUNDS[0];
    const holding = getHolding(fund.id);
    const tab = state.fundDetailTab;
    return `<div class="page">
      ${detailBar("基金详情", `<button class="detail-action" data-nav="#/orders">订单记录</button>`)}
      <div class="fund-detail-head">
        <div class="fund-name-row">
          <div style="flex:1;min-width:0">
            <h1>${esc(fund.name)}</h1>
            <div class="fund-code">${esc(fund.isin)} · ${esc(fund.currency)}</div>
          </div>
          <button class="watch-btn ${state.watchlist.includes(fund.id) ? "is-on" : ""}" data-action="toggle-watch" data-id="${fund.id}" aria-label="自选">${icon("heart")}</button>
        </div>
        <div class="fund-quote">
          <div><div class="q-label">近一年涨跌幅</div><div class="q-return ${signClass(fund.y1)}">${signedPct(fund.y1)}</div></div>
          <div><div class="q-label">单位净值（${esc(fund.navDate)}）</div><div class="q-nav">${fund.nav ? money(fund.nav, 8) : "—"}<small>${esc(fund.currency)}</small></div></div>
        </div>
        <div class="fund-tagline">${tag(fund.risk, fund.riskLevel >= 4 ? "" : "green")}${tag(fund.currency, "gold")}${tag(fund.type)}${fund.tags.includes("私募基金") || fund.tags.includes("私募") ? tag("私募基金", "blue") : ""}</div>
      </div>
      <div class="seg-tabs">
        ${[["trend", "业绩走势"], ["history", "历史业绩"], ["nav", "净值历史"]].map(([id, label]) => `<button class="seg-tab ${tab === id ? "is-active" : ""}" data-action="fund-tab" data-tab="${id}">${label}</button>`).join("")}
      </div>
      <div class="content" style="padding-top:13px">
        ${tab === "trend" ? fundTrendPanel(fund) : tab === "history" ? fundHistoryPanel(fund) : fundNavPanel(fund)}
        ${fundRulesCard(fund)}
        ${fundOverviewCard(fund)}
        <div class="risk-warning">本基金为${esc(fund.risk)}产品，历史业绩不代表未来表现。投资前请充分了解基金的风险收益特征，并根据自身风险承受能力谨慎决策。</div>
      </div>
    </div>`;
  }

  function fundTrendPanel(fund) {
    const data = pickSeries(fund, state.fundPeriod);
    const labels = periodLabels(state.fundPeriod);
    return `<section class="chart-panel">
      <div class="chart-top"><span class="chart-label">单位净值走势</span><span class="chart-legend"><i></i>单位净值</span></div>
      ${bigChart(data, "#c8942b")}
      <div class="chart-axis">${labels.map((l) => `<span>${l}</span>`).join("")}</div>
      <div class="period-tabs">${[["1m", "近1月"], ["3m", "近3月"], ["6m", "近6月"], ["1y", "近1年"], ["all", "成立以来"]].map(([id, label]) => `<button class="period-tab ${state.fundPeriod === id ? "is-active" : ""}" data-action="fund-period" data-period="${id}">${label}</button>`).join("")}</div>
    </section>`;
  }

  function fundHistoryPanel(fund) {
    return `<section class="perf-table">
      <div class="perf-row head"><span>时间区间</span><span>涨跌幅</span><span>最大回撤</span></div>
      ${fund.perf.map(([label, val, dd]) => `<div class="perf-row"><span>${label}</span><span class="${val.startsWith("+") ? "up" : val.startsWith("-") ? "down" : "muted"}">${val}</span><span>${dd}</span></div>`).join("")}
    </section>
    <div class="section-card" style="box-shadow:none;border:1px solid var(--line)">
      <div class="section-head" style="margin-bottom:5px"><h2 style="font-size:13px">业绩说明</h2></div>
      <div class="product-note" style="white-space:normal;line-height:1.8;font-size:9.5px">基金历史业绩不代表其未来表现。最大回撤指选定区间内净值从最高点回落至最低点的幅度，仅用于风险特征展示。</div>
    </div>`;
  }

  function fundNavPanel(fund) {
    if (!fund.navHistory.length) return emptyState("doc", "暂无净值数据", "该产品尚在募集期，净值将在成立后更新");
    return `<section class="nav-table">
      <div class="nav-row head"><span>日期</span><span>单位净值</span><span>日涨跌幅</span></div>
      ${fund.navHistory.map(([date, nav, chg]) => `<div class="nav-row"><span>${date}</span><span>${nav}</span><span class="${chg.startsWith("+") ? "up" : chg.startsWith("-") ? "down" : "muted"}">${chg}</span></div>`).join("")}
      <div class="news-more" style="padding:14px 0 10px">查看更多</div>
    </section>`;
  }

  function fundRulesCard(fund) {
    return `<section class="info-card">
      <div class="info-head"><h3>交易规则</h3><button class="info-link" data-nav="#/rules/${fund.id}">交易流程、费率 ${icon("chevronRight")}</button></div>
      <div class="rule-timeline">
        <div class="rule-step is-first"><i></i><span>17:00 前</span><strong>买入提交</strong></div>
        <div class="rule-step"><i></i><span>T+2</span><strong>申购确认</strong></div>
        <div class="rule-step is-last"><i></i><span>T+5</span><strong>申购交收</strong></div>
      </div>
      <div class="rule-fees"><span>首次最低申购额 <strong>${money(fund.min, 0)} ${esc(fund.currency)}</strong></span><span>申购费率 <strong>${fund.feeRate}%</strong></span></div>
    </section>`;
  }

  function fundOverviewCard(fund) {
    return `<section class="fund-overview">
      <details class="fund-accordion" open>
        <summary>基金档案 <span class="chev">${icon("chevronRight")}</span></summary>
        <div class="acc-body">
          <div class="manager-row"><div class="manager-avatar">${esc(fund.badge.slice(0, 1))}</div><div><strong style="font-size:11.5px;color:var(--ink-2)">${esc(fund.manager)}</strong><span style="display:block;font-size:9px;margin-top:3px;color:var(--muted)">基金管理人</span></div></div>
          基金代码：${esc(fund.code)}<br/>成立日期：${esc(fund.inception)}<br/>基金规模：${esc(fund.scale)}<br/>风险等级：${esc(fund.risk)}
        </div>
      </details>
      <details class="fund-accordion">
        <summary>基金文件 <span class="chev">${icon("chevronRight")}</span></summary>
        <div class="acc-body">
          <div class="doc-row"><span>基金说明书</span><span>PDF</span></div>
          <div class="doc-row"><span>产品资料概要</span><span>PDF</span></div>
          <div class="doc-row"><span>风险揭示书</span><span>PDF</span></div>
        </div>
      </details>
      <details class="fund-accordion">
        <summary>投资策略 <span class="chev">${icon("chevronRight")}</span></summary>
        <div class="acc-body">${esc(fund.desc)}</div>
      </details>
      <details class="fund-accordion">
        <summary>风险提示 <span class="chev">${icon("chevronRight")}</span></summary>
        <div class="acc-body">基金投资有风险，投资者在投资前应当认真阅读基金合同、招募说明书等法律文件，了解基金的风险收益特征，并根据自身的投资目的、投资期限、投资经验、资产状况等判断基金是否和投资者的风险承受能力相适应。</div>
      </details>
    </section>`;
  }

  function pageRules(route) {
    const fund = getFund(route.id) || FUNDS[0];
    return `<div class="page">
      ${detailBar("交易规则")}
      <div class="content" style="padding-top:8px">
        <section class="section-card">
          <div class="section-head"><h2>申购流程</h2><span class="tag">${fund.currency}</span></div>
          <div class="rule-timeline" style="margin-top:9px">
            <div class="rule-step is-first"><i></i><span>17:00 前</span><strong>买入提交</strong></div>
            <div class="rule-step"><i></i><span>T+2</span><strong>申购确认</strong></div>
            <div class="rule-step is-last"><i></i><span>T+5</span><strong>申购交收</strong></div>
          </div>
          <div class="rule-fees"><span>首次最低申购额 <strong>${money(fund.min, 0)} ${esc(fund.currency)}</strong></span><span>续投金额 <strong>10 ${esc(fund.currency)}</strong></span></div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>赎回流程</h2></div>
          <div class="rule-timeline" style="margin-top:9px">
            <div class="rule-step is-first"><i></i><span>17:00 前</span><strong>赎回提交</strong></div>
            <div class="rule-step"><i></i><span>T+2</span><strong>赎回确认</strong></div>
            <div class="rule-step is-last"><i></i><span>T+5</span><strong>资金到账</strong></div>
          </div>
          <div class="rule-fees"><span>赎回费率 <strong>0.00%</strong></span><span>到账币种 <strong>${esc(fund.currency)}</strong></span></div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>费用明细</h2></div>
          <div class="detail-list" style="margin:0;padding:0;box-shadow:none">
            <div class="row"><span>申购费率</span><strong>${fund.feeRate.toFixed(2)}%</strong></div>
            <div class="row"><span>赎回费率</span><strong>0.00%</strong></div>
            <div class="row"><span>管理年费</span><strong>0.25%</strong></div>
            <div class="row"><span>销售服务费</span><strong>0.00%</strong></div>
          </div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>其他信息</h2></div>
          <div class="detail-list" style="margin:0;padding:0;box-shadow:none">
            <div class="row"><span>交易币种</span><strong>${esc(fund.currency)}</strong></div>
            <div class="row"><span>交易时间</span><strong>交易日 9:00–17:00</strong></div>
            <div class="row"><span>分红方式</span><strong>现金分红 / 红利再投资</strong></div>
            <div class="row"><span>基金代码</span><strong>${esc(fund.code)}</strong></div>
          </div>
        </section>
        <div class="notice-line">以上交易规则为界面演示信息，实际费率、确认与交收时间以基金合同及销售文件为准。</div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Structured detail
     ---------------------------------------------------------- */
  function pageStructured(route) {
    const p = STRUCTURED_MAP[route.id] || STRUCTURED[0];
    return `<div class="page">
      ${detailBar("产品详情", `<button class="detail-action" data-action="toast" data-msg="产品文件 · 演示入口">产品文件</button>`)}
      <div class="structured-hero">
        <div class="st-tag">${tag(p.currency, "gold")}${tag("专业投资者", "gold")}</div>
        <h1>${esc(p.name)}</h1>
        <div class="st-code">${esc(p.code)}</div>
        <div class="st-metrics">
          <div><strong>${p.annual.toFixed(2)}%</strong><span>年化票息</span></div>
          <div><strong>${p.strike}%</strong><span>行使价</span></div>
          <div><strong>${p.knock}%</strong><span>敲出界限</span></div>
        </div>
      </div>
      <div class="content" style="padding-top:12px">
        <section class="section-card">
          <div class="section-head"><h2>产品要素</h2><span class="tag">${p.term} 个月</span></div>
          <div class="detail-list" style="margin:0;padding:0;box-shadow:none">
            <div class="row"><span>发行币种</span><strong>${p.currency}</strong></div>
            <div class="row"><span>起购金额</span><strong>${money(p.min, 0)} ${p.currency}</strong></div>
            <div class="row"><span>发行日</span><strong>${p.issue}</strong></div>
            <div class="row"><span>到期日</span><strong>${p.maturity}</strong></div>
            <div class="row"><span>产品期限</span><strong>${p.term} 个月</strong></div>
            <div class="row"><span>收益类型</span><strong>非保本浮动收益</strong></div>
          </div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>挂钩标的</h2></div>
          ${p.underlying === "APPLE" ? `<div class="underlying-row"><div class="u-logo">A</div><div><strong>Apple Inc.</strong><span>NASDAQ · AAPL</span></div><div class="u-val up">+1.24%</div></div>` : `<div class="underlying-row"><div class="u-logo" style="background:linear-gradient(135deg,#3c5474,#1d2c44)">P</div><div><strong>${esc(p.underlyingName)}</strong><span>多资产组合</span></div><div class="u-val muted">—</div></div>`}
          <div class="product-note" style="white-space:normal;line-height:1.75;font-size:9.5px;margin-top:10px">${esc(p.desc)}</div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>产品文件</h2><span class="tag tag--green">已上线</span></div>
          ${["产品说明书", "风险揭示书", "产品资料概要"].map((d) => `<button class="doc-link" data-action="toast" data-msg="${d} · PDF 预览演示"><span>${icon("doc")}${d}</span><span class="muted small">PDF ${icon("chevronRight")}</span></button>`).join("")}
        </section>
        <div class="risk-warning">结构化产品涉及衍生品结构，可能面临标的价格波动、提前终止、流动性及信用风险。仅适合具备相应风险识别与承受能力的专业投资者。</div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Orders
     ---------------------------------------------------------- */
  function pageOrders() {
    let list = state.orders.slice();
    if (state.orderFilter.type !== "all") list = list.filter((o) => o.type === state.orderFilter.type);
    if (state.orderFilter.fund !== "all") list = list.filter((o) => o.fundId === state.orderFilter.fund);
    const fundOptions = [{ label: "全部基金", value: "all" }].concat(
      [...new Set(state.orders.map((o) => o.fundId))]
        .map((id) => ({ label: getFund(id)?.name || state.orders.find((o) => o.fundId === id)?.name || id, value: id }))
    );
    return `<div class="page">
      ${detailBar("订单记录")}
      <div class="order-filters">
        <button class="order-filter" data-action="order-filter" data-key="fund">${fundOptions.find((o) => o.value === state.orderFilter.fund)?.label || "全部基金"}${icon("chevronDown")}</button>
        <button class="order-filter" data-action="order-filter" data-key="type">${state.orderFilter.type === "all" ? "全部类型" : state.orderFilter.type}${icon("chevronDown")}</button>
      </div>
      ${list.length ? `<div>${list.map((o) => orderCard(o)).join("")}</div><div class="news-more">— 没有更多了 —</div>` : `<div class="order-empty"><div class="empty-icon">${icon("orders")}</div><h3>暂无订单记录</h3><p>申购或赎回基金后，可在这里查看订单进度</p></div>`}
    </div>`;
  }

  function orderStatusClass(status) {
    if (status.includes("确认") || status.includes("待")) return "";
    if (status.includes("完成")) return "done";
    if (status.includes("撤销") || status.includes("失败")) return "cancelled";
    return "";
  }

  function orderCard(o) {
    return `<article class="order-card" data-nav="#/order/${o.id}">
      <div class="order-card-top"><span class="order-type">${esc(o.type)}</span><span class="order-status ${orderStatusClass(o.status)}">${esc(o.status)}</span></div>
      <div class="order-lines">
        <div class="order-line"><span>基金名称</span><strong>${esc(o.name)}</strong></div>
        <div class="order-line"><span>金额</span><strong>${esc(o.currency || "HKD")} ${money(o.amount)}</strong></div>
        <div class="order-line"><span>时间</span><strong>${esc(o.date)}</strong></div>
      </div>
    </article>`;
  }

  function pageOrderDetail(route) {
    const order = state.orders.find((o) => o.id === route.id);
    if (!order) {
      return `<div class="page">${detailBar("订单详情")}<div class="order-empty"><div class="empty-icon">${icon("alert")}</div><h3>订单不存在</h3><p>该订单可能已被删除</p></div></div>`;
    }
    const fund = getFund(order.fundId);
    const pending = order.status.includes("待确认") || order.status.includes("已提交");
    return `<div class="page">
      ${detailBar("订单详情", `<button class="detail-action" data-action="toast" data-msg="订单凭证已生成">凭证</button>`)}
      <div class="order-detail-hero"><h2>${esc(order.name)}</h2><div class="code">${esc(fund?.isin || order.code || "")}</div></div>
      <section class="detail-list">
        <div class="row"><span>订单状态</span><strong style="color:${pending ? "var(--blue)" : order.status.includes("完成") ? "var(--up)" : "var(--muted)"}">${esc(order.status)}</strong></div>
        <div class="row"><span>订单时间</span><strong>${esc(order.date)}</strong></div>
        <div class="row"><span>订单号</span><strong>${esc(order.orderNo)}</strong></div>
      </section>
      <section class="detail-list">
        <div class="row"><span>订单类型</span><strong>${esc(order.type)}</strong></div>
        <div class="row"><span>${order.type === "赎回" ? "赎回份额" : "申购金额"}</span><strong>${order.type === "赎回" && order.shares ? `${money(order.shares, 4)} 份` : `${esc(order.currency || "HKD")} ${money(order.amount)}`}</strong></div>
        <div class="row"><span>手续费</span><strong>${money(order.fee)} ${esc(order.currency || "HKD")}</strong></div>
        <div class="row"><span>${order.type === "赎回" ? "预计到账" : "买入金额"}</span><strong>${esc(order.currency || "HKD")} ${money(order.amount)}</strong></div>
      </section>
      ${pending ? `<div class="status-banner"><div class="b-icon">${icon("clock")}</div><div><strong>订单已提交，等待基金公司确认</strong><p>预计 T+2 个交易日完成确认，确认后可在订单记录中查看最新状态。</p></div></div>` : ""}
    </div>`;
  }

  /* ----------------------------------------------------------
     Holdings
     ---------------------------------------------------------- */
  function pageHoldings() {
    const total = state.holdings.reduce((s, h) => s + holdingValue(h), 0);
    const profit = state.holdings.reduce((s, h) => s + holdingProfit(h), 0);
    return `<div class="page">
      ${detailBar("基金持仓", `<button class="detail-action" data-nav="#/orders">订单记录</button>`)}
      <div class="content" style="padding-top:6px">
        <section class="section-card" style="background:linear-gradient(145deg,#22344d,#17263c);color:#fff">
          <div class="small" style="color:rgba(255,255,255,.55)">基金持仓市值（HKD）</div>
          <div style="font-size:30px;font-weight:700;letter-spacing:-.03em;margin-top:7px">${maskMoney(total)}</div>
          <div class="small" style="margin-top:8px;color:#f0d28c">持仓盈亏 ${state.hideAmounts ? "••••" : `+${money(profit)}`}</div>
        </section>
        ${state.holdings.map((h) => {
          const f = getFund(h.fundId);
          if (!f) return "";
          const value = holdingValue(h);
          const p = holdingProfit(h);
          return `<section class="section-card" data-nav="#/fund/${f.id}">
            <div class="product-head">${fundBadge(f)}<div class="product-title"><h3>${esc(f.name)}</h3><p><span class="product-code">${esc(f.code)}</span>${tag("HKD", "gold")}</p></div><span class="tag tag--green">持有中</span></div>
            <div class="product-metrics" style="margin-top:15px">
              <div class="metric"><strong>${maskMoney(value)}</strong><span>持仓市值</span></div>
              <div class="metric"><strong>${money(h.shares, 0)}</strong><span>持有份额</span></div>
              <div class="metric"><strong class="up">${state.hideAmounts ? "••••" : `+${money(p)}`}</strong><span>持仓盈亏</span></div>
            </div>
            <div class="product-foot"><span class="product-note"><i></i>成本净值 ${money(h.cost, 2)} · 最新净值 ${money(f.nav, 2)}</span><button class="btn btn-sm btn--soft" data-action="open-redeem" data-id="${f.id}">赎回</button></div>
          </section>`;
        }).join("") || emptyState("wallet", "暂无基金持仓", "完成申购并经基金公司确认后，持仓会展示在这里")}
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Search
     ---------------------------------------------------------- */
  function pageSearch() {
    return `<div class="page">
      <div class="detail-bar">
        <button class="back" data-action="back" aria-label="返回">${icon("chevronLeft")}</button>
        <div class="search-bar" style="flex:1;margin:0;box-shadow:none;background:#eef1f5">
          ${icon("search")}<input id="search-input" type="search" placeholder="搜索基金、代码或结构化产品" value="${esc(state.searchQuery)}" autocomplete="off" />
          ${state.searchQuery ? `<button class="icon-btn" data-action="search-clear" style="width:22px;height:22px">${icon("close")}</button>` : ""}
        </div>
        <button class="search-cancel" data-action="back">取消</button>
      </div>
      <div id="search-body">${searchBody(state.searchQuery)}</div>
    </div>`;
  }

  function searchBody(query) {
    const q = query.trim();
    if (!q) {
      return `<div class="search-block">
        <h3>热门搜索</h3>
        <div class="search-tags">${HOT_SEARCHES.map((h) => `<button class="chip" data-action="search-hot" data-q="${h}">${h}</button>`).join("")}</div>
        <h3 style="margin-top:24px">最近搜索</h3>
        <div class="section-card" style="padding:2px 14px;box-shadow:none;border:1px solid var(--line)">
          ${state.recentSearches.map((r) => `<button class="recent-row" data-action="search-hot" data-q="${esc(r)}" style="width:100%;text-align:left">${icon("clock")}<span>${esc(r)}</span>${icon("chevronRight")}</button>`).join("")}
        </div>
        <h3 style="margin-top:24px">按类别浏览</h3>
        <div class="search-tags">
          <button class="chip" data-action="go-products" data-tab="public">公募基金</button>
          <button class="chip" data-action="go-products" data-tab="private">私募基金</button>
          <button class="chip" data-action="go-products" data-tab="structured">结构化产品</button>
          <button class="chip" data-nav="#/products">全部产品</button>
        </div>
      </div>`;
    }
    const needle = q.toLowerCase();
    const fundResults = FUNDS.filter((f) => `${f.name} ${f.code} ${f.isin} ${f.type}`.toLowerCase().includes(needle));
    const structuredResults = STRUCTURED.filter((p) => `${p.name} ${p.code} ${p.underlying}`.toLowerCase().includes(needle));
    const count = fundResults.length + structuredResults.length;
    if (!count) {
      return `<div class="product-empty" style="margin-top:18px"><div class="empty-icon">${icon("search")}</div><h3>没有找到“${esc(q)}”</h3><p>试试搜索基金名称、代码或产品关键词</p></div>`;
    }
    return `<div class="search-block" style="padding-top:2px">
      <div class="small muted" style="padding:0 2px 10px">找到 ${count} 个相关产品</div>
      ${fundResults.length ? `<div class="search-result">${fundResults.map((f) => `<button class="fund-list-row" data-nav="#/fund/${f.id}" style="width:100%;text-align:left"><div class="fund-list-name"><strong>${esc(f.name)}</strong><p>${tag(f.currency)}<span class="product-code">${esc(f.code)}</span>${tag(f.type)}</p></div><div class="fund-list-num ${signClass(f.y1)}">${signedPct(f.y1)}<span>近一年</span></div></button>`).join("")}</div>` : ""}
      ${structuredResults.length ? `<div class="search-result" style="margin-top:12px">${structuredResults.map((p) => `<button class="fund-list-row" data-nav="#/structured/${p.id}" style="width:100%;text-align:left"><div class="fund-list-name"><strong>${esc(p.name)}</strong><p>${tag(p.currency, "gold")}${tag("结构化", "blue")}</p></div><div class="fund-list-num">${p.annual.toFixed(2)}%<span>年化票息</span></div></button>`).join("")}</div>` : ""}
    </div>`;
  }

  /* ----------------------------------------------------------
     Deposit / withdraw / exchange
     ---------------------------------------------------------- */
  function pageDeposit() {
    const d = state.deposit;
    const currencyName = { HKD: "港币", USD: "美元", CNY: "人民币" }[d.currency];
    return `<div class="page">
      ${detailBar("存入资金", `<button class="detail-action" data-action="toast" data-msg="入金记录 · 演示入口">入金记录</button>`)}
      ${stepper(d.step === 1 ? 1 : 2)}
      ${d.step === 1 ? `<div>
        <section class="panel">
          <div class="panel-title"><span>选择存入币种</span><span class="hint">支持多币种入金</span></div>
          <div class="currency-grid">
            ${[["HKD", "港币", "HK", "#b23a3b"], ["USD", "美元", "$", "#4f70a8"], ["CNY", "人民币", "¥", "#d04a43"]].map(([code, name, symbol, color]) => `<button class="currency-card ${d.currency === code ? "is-active" : ""}" data-action="deposit-currency" data-currency="${code}"><div class="cur-head"><i style="background:${color}">${symbol}</i>${name}</div><span>${code} 账户</span></button>`).join("")}
          </div>
        </section>
        <section class="panel">
          <div class="panel-title"><span>存入金额</span><span class="hint">预计 T+1 到账</span></div>
          <div class="amount-box"><span class="currency-symbol">${d.currency === "CNY" ? "¥" : d.currency === "USD" ? "$" : "HK$"}</span><input id="deposit-amount" inputmode="decimal" placeholder="请输入金额" value="${esc(d.amount)}" /><span class="all">${currencyName}</span></div>
          <div class="amount-hint"><span>单笔最低入金 100 ${d.currency}</span><span>可用余额 4,851,219.28 HKD</span></div>
          <div class="quick-amounts">${[1000, 10000, 50000, 100000].map((n) => `<button class="chip" data-action="deposit-quick" data-amount="${n}">${money(n, 0)}</button>`).join("")}</div>
        </section>
        <section class="panel">
          <div class="panel-title"><span>收款银行账户</span><span class="hint">同名账户</span></div>
          ${bankCard("h", "汇丰银行", "HSBC · 香港", "004-848-123456-838", "red")}
          <div class="radio-line" style="margin-top:10px">${icon("info")}请使用与证券账户同名的银行账户入金，否则可能被退回。</div>
        </section>
        <div class="notice-line">入金到账时间取决于银行处理速度，通常为 1–2 个工作日。演示环境不会发起真实转账。</div>
        <div class="form-actions"><button class="btn btn--primary btn--wide" data-action="deposit-next">下一步</button></div>
      </div>` : `<div>
        <section class="panel">
          <div class="panel-title"><span>请将资金汇至以下银行</span><span class="tag tag--green">待汇入</span></div>
          ${bankCard("h", "汇丰银行", "HSBC · 香港", "004-848-123456-838", "red", true)}
          <div class="detail-list" style="margin:8px 0 0;padding:0;box-shadow:none">
            <div class="row"><span>收款人名称</span><strong>SECURITIES LIMITED</strong></div>
            <div class="row"><span>汇款附言</span><strong>C10002286</strong></div>
            <div class="row"><span>预计到账</span><strong>T+1 个工作日</strong></div>
          </div>
          <div class="notice-line" style="margin:12px 0 0">请在转账附言中填写证券账户号，便于快速匹配入账。</div>
        </section>
        <section class="panel">
          <div class="panel-title"><span>本次入金金额</span><span class="hint">${d.currency}</span></div>
          <div class="sheet-total" style="padding-top:0;margin-top:0;border-top:0"><span>${currencyName}</span><strong>${d.currency} ${money(Number(d.amount) || 0)}</strong></div>
        </section>
        <div class="form-actions"><button class="btn btn--primary btn--wide" data-action="deposit-submit">我已转账，提交凭证</button><button class="btn btn--ghost btn--wide" style="margin-top:9px" data-action="deposit-back">返回修改</button></div>
      </div>`}
    </div>`;
  }

  function pageWithdraw() {
    const w = state.withdraw;
    const currencyName = { HKD: "港币", USD: "美元", CNY: "人民币" }[w.currency];
    return `<div class="page">
      ${detailBar("提取资金")}
      <div class="content" style="padding-top:7px">
        <section class="panel" style="margin:0">
          <div class="panel-title"><span>提款币种</span><span class="hint">可用余额 4,851,219.28 HKD</span></div>
          <div class="currency-grid">
            ${[["HKD", "港币", "HK", "#b23a3b"], ["USD", "美元", "$", "#4f70a8"], ["CNY", "人民币", "¥", "#d04a43"]].map(([code, name, symbol, color]) => `<button class="currency-card ${w.currency === code ? "is-active" : ""}" data-action="withdraw-currency" data-currency="${code}"><div class="cur-head"><i style="background:${color}">${symbol}</i>${name}</div><span>${code} 账户</span></button>`).join("")}
          </div>
        </section>
        <section class="panel" style="margin:0">
          <div class="panel-title"><span>提款金额</span><span class="hint">${currencyName}</span></div>
          <div class="amount-box"><span class="currency-symbol">${w.currency === "CNY" ? "¥" : w.currency === "USD" ? "$" : "HK$"}</span><input id="withdraw-amount" inputmode="decimal" placeholder="请输入金额" value="${esc(w.amount)}" /><button class="all" data-action="withdraw-all">全部提出</button></div>
          <div class="amount-hint"><span>预计 1–2 个工作日到账</span><span>提款手续费 0.00 ${w.currency}</span></div>
          <div class="quick-amounts">${[1000, 10000, 50000].map((n) => `<button class="chip" data-action="withdraw-quick" data-amount="${n}">${money(n, 0)}</button>`).join("")}</div>
        </section>
        <section class="panel" style="margin:0">
          <div class="panel-title"><span>收款银行账户</span><span class="hint">已认证</span></div>
          ${bankCard("b", "中国银行（香港）", "BOCHK · 香港", "012-888-542198-771", "red")}
          <div class="radio-line" style="margin-top:10px">${icon("shield")}资金将原路退回至已认证的银行账户，保障资金安全。</div>
        </section>
        <div class="form-actions" style="padding:4px 0 0"><button class="btn btn--primary btn--wide" data-action="withdraw-submit">确认提款</button></div>
      </div>
    </div>`;
  }

  function pageExchange() {
    const e = state.exchange;
    const rates = { "HKD-CNY": 0.912, "CNY-HKD": 1.0965, "HKD-USD": 0.1281, "USD-HKD": 7.806, "CNY-USD": 0.1404, "USD-CNY": 7.12 };
    const rate = rates[`${e.from}-${e.to}`] || 1;
    const amount = Number(e.amount) || 0;
    const converted = amount * rate;
    const names = { HKD: "港币", CNY: "人民币", USD: "美元" };
    return `<div class="page">
      ${detailBar("货币兑换", `<button class="detail-action" data-nav="#/orders">兑换记录</button>`)}
      <div class="content" style="padding-top:7px">
        <section class="panel" style="margin:0">
          <div class="panel-title"><span>兑换方向</span><span class="hint">实时汇率</span></div>
          <div class="exchange-row">
            <button class="exchange-side" data-action="exchange-pick" data-side="from"><span class="small muted">从</span><strong>${names[e.from]}</strong><span>${e.from}</span>${icon("chevronDown")}</button>
            <div class="exchange-switch" data-action="exchange-switch">${icon("exchange")}</div>
            <button class="exchange-side" data-action="exchange-pick" data-side="to"><span class="small muted">到</span><strong>${names[e.to]}</strong><span>${e.to}</span>${icon("chevronDown")}</button>
          </div>
          <div class="exchange-rate"><span>参考汇率 1 ${e.from} = <strong>${rate} ${e.to}</strong></span><span>更新时间 09:41</span></div>
        </section>
        <section class="panel" style="margin:0">
          <div class="panel-title"><span>兑换金额</span><span class="hint">可用余额 4,851,219.28 HKD</span></div>
          <div class="amount-box"><span class="currency-symbol">${e.from === "CNY" ? "¥" : e.from === "USD" ? "$" : "HK$"}</span><input id="exchange-amount" inputmode="decimal" placeholder="请输入金额" value="${esc(e.amount)}" /><span class="all">${e.from}</span></div>
          <div class="amount-hint"><span>预计可兑换</span><span id="exchange-estimate" style="color:var(--ink-2);font-weight:600">${e.to} ${money(converted)}</span></div>
          <div class="quick-amounts">${[1000, 10000, 50000].map((n) => `<button class="chip" data-action="exchange-quick" data-amount="${n}">${money(n, 0)}</button>`).join("")}</div>
        </section>
        <div class="notice-line">汇率仅供参考，实际成交汇率以交易时银行或做市商报价为准。演示环境不产生真实兑换。</div>
        <div class="form-actions" style="padding:2px 0 0"><button class="btn btn--primary btn--wide" data-action="exchange-submit">确认兑换</button></div>
      </div>
    </div>`;
  }

  function bankCard(id, name, sub, account, tone = "red", large = false) {
    return `<div class="bank-card">
      <div class="bank-logo bank-logo--${tone}">${name.slice(0, 2)}</div>
      <div class="bank-info"><strong>${name}</strong><span>${sub} · ${account}</span></div>
      <button class="copy-btn" data-action="copy" data-copy="${account}">复制</button>
    </div>`;
  }

  /* ----------------------------------------------------------
     Risk assessment
     ---------------------------------------------------------- */
  function getRiskResult() {
    const score = state.risk.answers.reduce((s, v) => s + (Number(v) + 1), 0);
    if (score <= 4) return { name: "保守型", level: 1, desc: "您更看重本金安全与流动性，建议以货币基金、短久期固收类产品为主，控制权益类资产比例。", scale: 1 };
    if (score <= 8) return { name: "稳健型", level: 2, desc: "您能够承受适度波动，建议以固收打底、均衡配置为主，适度参与优质权益资产。", scale: 2 };
    if (score <= 12) return { name: "成长型", level: 3, desc: "您具备较好的风险承受能力，可考虑提高权益类与多资产组合的配置比例，追求长期资本增值。", scale: 4 };
    return { name: "激进型", level: 4, desc: "您能够接受较大幅度的净值波动，可关注成长型权益、行业主题及结构化产品，并做好仓位与风险管理。", scale: 5 };
  }

  function pageRisk() {
    const r = state.risk;
    if (!r.started) {
      return `<div class="page">
        ${detailBar("风险测评")}
        <div class="content" style="padding-top:8px">
          <section class="risk-intro">
            <div class="shield">${icon("shield")}</div>
            <h2>了解自己，<br/>再开始投资。</h2>
            <p>用 4 个问题评估您的风险承受能力，帮助我们为您匹配更合适的产品。</p>
          </section>
          <section class="section-card">
            <div class="info-head"><h3>测评须知</h3><span class="tag tag--gold">约 1 分钟</span></div>
            <div class="detail-list" style="margin:10px 0 0;padding:0;box-shadow:none">
              <div class="row"><span>题目数量</span><strong>4 题</strong></div>
              <div class="row"><span>结果有效期</span><strong>12 个月</strong></div>
              <div class="row"><span>用途</span><strong>产品适当性匹配</strong></div>
            </div>
          </section>
          <div class="form-actions" style="padding:2px 0 0"><button class="btn btn--primary btn--wide" data-action="risk-start">开始测评</button></div>
        </div>
      </div>`;
    }
    if (r.done) {
      const result = getRiskResult();
      return `<div class="page">
        ${detailBar("风险测评结果")}
        <div class="content" style="padding-top:18px">
          <section class="risk-result-card">
            <div class="risk-result-badge">${icon("shield")}</div>
            <div class="eyebrow">YOUR RISK PROFILE</div>
            <h2>${result.name}</h2>
            <p>${result.desc}</p>
            <div class="risk-result-scale">${[1, 2, 3, 4, 5].map((i) => `<i class="${i <= result.scale ? "on" : ""}"></i>`).join("")}</div>
            <div class="result-info">
              <div><span>风险等级</span><strong>R${result.level} · ${result.name}</strong></div>
              <div><span>测评时间</span><strong>2026-09-14</strong></div>
              <div><span>有效期至</span><strong>2027-09-14</strong></div>
              <div><span>适当性匹配</span><strong class="up">已完成</strong></div>
            </div>
          </section>
          <div class="form-actions" style="padding:2px 0 0"><button class="btn btn--primary btn--wide" data-action="risk-finish">完成</button><button class="btn btn--ghost btn--wide" style="margin-top:9px" data-action="risk-reset">重新测评</button></div>
        </div>
      </div>`;
    }
    const q = RISK_QUESTIONS[r.step];
    const pct = ((r.step) / RISK_QUESTIONS.length) * 100;
    return `<div class="page">
      ${detailBar("风险测评")}
      <div class="risk-progress"><div class="bar"><i style="width:${Math.max(8, pct)}%"></i></div><span>${r.step + 1} / ${RISK_QUESTIONS.length}</span></div>
      <section class="question-card">
        <div class="question-index">QUESTION 0${r.step + 1}</div>
        <h3>${q.q}</h3>
        ${q.options.map((opt, i) => `<button class="risk-option ${r.answers[r.step] === i ? "is-selected" : ""}" data-action="risk-answer" data-index="${i}"><i></i>${opt}</button>`).join("")}
      </section>
      <div class="section-caption" style="text-align:center;padding:16px">选择最符合您实际情况的选项</div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Professional investor
     ---------------------------------------------------------- */
  function pageProfessional() {
    return `<div class="page">
      ${detailBar("专业投资者")}
      <div class="content" style="padding-top:8px">
        <section class="risk-intro" style="padding:24px 20px">
          <div class="shield" style="color:#f5d98f">${icon("star")}</div>
          <div class="eyebrow" style="color:rgba(255,255,255,.5)">PROFESSIONAL INVESTOR</div>
          <h2>更广阔的产品边界</h2>
          <p>专业投资者可获取更丰富的产品与服务，包括私募基金、结构性产品及定制化资产配置方案。</p>
          <div style="margin-top:20px">${tag(state.isProfessional ? "已通过认证" : "待认证", "gold")}</div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2>专业投资者权益</h2></div>
          ${[
            ["更丰富的产品货架", "私募基金、结构化产品及另类资产"],
            ["专属资产配置服务", "投资顾问一对一沟通与组合建议"],
            ["优先参与新发产品", "热门产品额度优先预约"],
          ].map(([t, d]) => `<div class="benefit-row"><span class="benefit-icon">${icon("checkCircle")}</span><div><strong>${t}</strong><p>${d}</p></div></div>`).join("")}
        </section>
        <section class="section-card">
          <div class="section-head"><h2>认证条件</h2></div>
          <div class="detail-list" style="margin:0;padding:0;box-shadow:none">
            <div class="row"><span>资产要求</span><strong>不低于 800 万港元</strong></div>
            <div class="row"><span>投资经验</span><strong>2 年以上</strong></div>
            <div class="row"><span>认证状态</span><strong class="up">已通过</strong></div>
          </div>
        </section>
        <div class="notice-line">专业投资者认定需符合当地监管要求。原型中的认证状态为演示数据。</div>
        <div class="form-actions" style="padding:2px 0 0"><button class="btn btn--gold btn--wide" data-action="toast" data-msg="专业投资者资料 · 演示入口">查看我的认证资料</button></div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Asset analysis
     ---------------------------------------------------------- */
  function pageAnalysis() {
    return `<div class="page">
      ${detailBar("资产分析", `<button class="detail-action" data-action="toast" data-msg="分析报告 · 演示入口">报告</button>`)}
      <div class="content" style="padding-top:8px">
        <section class="analysis-total">
          <div class="label">累计资产净值（HKD）</div>
          <div class="value">${maskMoney(5162601.66)}</div>
          <div class="delta up">今日盈亏 +28,799.93 · 较上月 +1.28%</div>
        </section>
        <section class="analysis-chart-card">
          <div class="section-head"><h2 style="font-size:14px">资产分布</h2><span class="tag">09-14</span></div>
          <div class="donut-wrap">
            <div class="donut"><div class="center"><strong>100%</strong>总资产</div></div>
            <div class="legend">
              <div class="legend-row"><i style="background:#c99629"></i>基金及结构化<span>48%</span></div>
              <div class="legend-row"><i style="background:#354e71"></i>港股<span>24%</span></div>
              <div class="legend-row"><i style="background:#7fa6bd"></i>现金及等价物<span>16%</span></div>
              <div class="legend-row"><i style="background:#d8dee7"></i>其他市场<span>12%</span></div>
            </div>
          </div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2 style="font-size:14px">收益概览</h2></div>
          <div class="analysis-row"><span>累计盈利</span><strong class="up">+6,602.82 HKD</strong></div>
          <div class="analysis-row"><span>累计亏损</span><strong class="down">-1,040,396.62 HKD</strong></div>
          <div class="analysis-row"><span>交易胜率</span><strong>62.50%</strong></div>
          <div class="analysis-row"><span>持仓集中度</span><strong>中高</strong></div>
        </section>
        <section class="section-card">
          <div class="section-head"><h2 style="font-size:14px">近 30 日资产走势</h2><span class="up small">+1.28%</span></div>
          ${bigChart([4660000, 4680000, 4670000, 4720000, 4700000, 4750000, 4780000, 4760000, 4820000, 4860000, 4830000, 4910000, 4950000, 4930000, 5010000, 5060000, 5040000, 5110000, 5162601.66], "#c8942b")}
          <div class="chart-axis"><span>08-15</span><span>08-23</span><span>09-01</span><span>09-09</span><span>09-14</span></div>
        </section>
        <div class="notice-line">资产分析数据为演示数据，不代表真实投资收益。</div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Stock detail
     ---------------------------------------------------------- */
  function pageStock(route) {
    const s = getStock(route.id) || MARKET_DATA.hk.indices[0];
    const up = s.chg >= 0;
    return `<div class="page">
      ${detailBar("行情详情", `<button class="detail-action" data-action="toast" data-msg="已切换至专业行情（演示）">专业行情</button>`)}
      <div class="stock-head">
        <div class="stock-name">${esc(s.name)}<span>${esc(s.market)}</span></div>
        <div class="stock-code">${esc(s.code)} · 延时至少 15 分钟</div>
      </div>
      <div class="stock-price">
        <div class="price ${up ? "up" : "down"}">${money(s.price)}</div>
        <div class="change ${up ? "up" : "down"}">${up ? "+" : ""}${money(s.chgAbs || 0)}  ${signedPct(s.chg)}</div>
      </div>
      <div style="margin:13px 16px 0;background:#fff;border-radius:var(--r-lg);padding:10px 8px 4px;box-shadow:var(--shadow-sm)">
        <div class="chart-top" style="padding:0 8px 4px"><span class="chart-label">分时走势</span><span class="chart-legend"><i style="background:${up ? "var(--up)" : "var(--down)"}"></i>${esc(s.market)}</span></div>
        ${bigChart(s.series, up ? "#0c9f6e" : "#df5361", true)}
        <div class="chart-axis"><span>09:30</span><span>11:00</span><span>13:00</span><span>15:00</span><span>16:00</span></div>
      </div>
      <div class="stock-stats">
        <div class="stock-stat"><span>今开</span><strong>${money(s.price * 0.993)}</strong></div>
        <div class="stock-stat"><span>最高</span><strong>${money(s.price * 1.012)}</strong></div>
        <div class="stock-stat"><span>最低</span><strong>${money(s.price * 0.985)}</strong></div>
        <div class="stock-stat"><span>昨收</span><strong>${money(s.price / (1 + s.chg / 100))}</strong></div>
        <div class="stock-stat"><span>成交额</span><strong>${s.market === "美股" ? "347.60亿" : "282.28亿"}</strong></div>
        <div class="stock-stat"><span>市盈率</span><strong>${s.market === "美股" ? "27.34" : "11.68"}</strong></div>
      </div>
      <section class="stock-about">
        <div class="section-head"><h3>行情简介</h3><span class="tag">延时</span></div>
        <p>${esc(s.desc || `${s.name} 为${s.market}市场代表性标的，行情数据仅用于界面演示。`)}</p>
      </section>
      <div class="notice-line" style="margin-top:12px">行情数据由演示数据提供，不构成任何投资建议。</div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Success
     ---------------------------------------------------------- */
  function pageSuccess() {
    const d = state.successData || {
      title: "操作已提交",
      subtitle: "请稍后查看订单状态",
      rows: [],
      kind: "general",
    };
    return `<div class="page">
      <div class="detail-bar"><div style="width:40px"></div><div class="detail-title">${d.kind === "buy" ? "申购结果" : d.kind === "redeem" ? "赎回结果" : "提交结果"}</div><div style="width:40px"></div></div>
      <div class="success-page">
        <div class="success-mark">${icon("check")}</div>
        <h1>${esc(d.title)}</h1>
        <p>${esc(d.subtitle)}</p>
        <div class="success-summary">
          ${d.rows.map(([label, value]) => `<div class="row"><span>${label}</span><strong>${value}</strong></div>`).join("")}
        </div>
        <div class="success-actions">
          <button class="btn btn--ghost" data-nav="#/orders">查看订单</button>
          <button class="btn btn--primary" data-action="success-done">完成</button>
        </div>
        <div class="success-tips">${d.kind === "buy" ? "申购份额将在基金公司确认后更新。您可以在「订单记录」中随时查看处理进度。" : d.kind === "redeem" ? "赎回资金预计 T+2 至 T+5 个工作日到账，具体以基金公司确认时间为准。" : "演示环境不会发起真实资金划转。"}</div>
      </div>
    </div>`;
  }

  /* ----------------------------------------------------------
     Sheet rendering
     ---------------------------------------------------------- */
  function renderOverlay() {
    if (state.pin) return pinSheet();
    if (!state.sheet) return "";
    if (state.sheet.type === "buy") return buySheet();
    if (state.sheet.type === "redeem") return redeemSheet();
    if (state.sheet.type === "structured") return structuredSheet();
    if (state.sheet.type === "options") return optionsSheet();
    return "";
  }

  function overlayWrap(inner, extra = "") {
    return `<div class="overlay"><div class="sheet ${extra}" data-stop="1">${inner}</div></div>`;
  }

  function buySheet() {
    const s = state.sheet;
    const fund = getFund(s.fundId);
    if (!fund) return "";
    const amount = Number(s.amount) || 0;
    const shares = fund.nav ? amount / fund.nav : 0;
    const fee = 0;
    return overlayWrap(`<div class="sheet-grabber"></div>
      <div class="sheet-head"><div><h2>申购基金</h2><p>确认金额与交易信息</p></div><button class="sheet-close" data-action="close-sheet">${icon("close")}</button></div>
      <div class="sheet-fund">${fundBadge(fund, true)}<div><h3>${esc(fund.name)}</h3><p>${esc(fund.code)} · ${esc(fund.risk)}</p></div><div class="sf-right">最新净值<strong>${money(fund.nav, 4)}</strong></div></div>
      <div class="sheet-label"><span>申购金额</span><span>可用余额 <strong>4,851,219.28 HKD</strong></span></div>
      <div class="amount-box" style="border:1px solid var(--line-strong);border-radius:12px;padding:11px 12px;background:#fafbfc">
        <span class="currency-symbol" style="font-size:18px">HK$</span><input id="buy-amount" inputmode="decimal" placeholder="0.00" value="${esc(s.amount)}" style="font-size:25px" />
      </div>
      <div class="quick-amounts">${[1000, 5000, 10000, 50000].map((n) => `<button class="chip ${Number(s.amount) === n ? "chip--active" : ""}" data-action="buy-quick" data-amount="${n}">${money(n, 0)}</button>`).join("")}</div>
      <div style="margin-top:15px;background:#fafbfc;border-radius:12px;padding:10px 12px">
        <div class="sheet-line"><span>预计份额</span><strong id="buy-shares">${money(shares, 4)} 份</strong></div>
        <div class="sheet-line"><span>申购费率</span><strong>${fund.feeRate.toFixed(2)}%</strong></div>
        <div class="sheet-line"><span>手续费</span><strong id="buy-fee">HKD 0.00</strong></div>
        <div class="sheet-total"><span>买入金额</span><strong id="buy-total">HKD ${money(amount)}</strong></div>
      </div>
      <div class="agreement" data-action="toggle-agree"><span class="check ${s.agreed ? "is-on" : ""}">${icon("check")}</span><span>我已阅读并同意<strong>《基金风险揭示书》</strong>及<strong>《产品资料概要》</strong>，确认本人风险承受能力与产品风险等级相匹配。</span></div>
      <button class="btn btn--primary btn--wide" data-action="confirm-buy">确认申购</button>
    </div>`);
  }

  function redeemSheet() {
    const s = state.sheet;
    const fund = getFund(s.fundId);
    const holding = getHolding(s.fundId);
    if (!fund || !holding) return "";
    const shares = Number(s.shares) || 0;
    const estimate = shares * fund.nav;
    return overlayWrap(`<div class="sheet-grabber"></div>
      <div class="sheet-head"><div><h2>赎回基金</h2><p>赎回份额将在确认后从持仓中扣除</p></div><button class="sheet-close" data-action="close-sheet">${icon("close")}</button></div>
      <div class="sheet-fund">${fundBadge(fund, true)}<div><h3>${esc(fund.name)}</h3><p>${esc(fund.code)} · 可赎 ${money(holding.shares, 4)} 份</p></div><div class="sf-right">最新净值<strong>${money(fund.nav, 4)}</strong></div></div>
      <div class="sheet-label"><span>赎回份额</span><span>全部赎回</span></div>
      <div class="amount-box" style="border:1px solid var(--line-strong);border-radius:12px;padding:11px 12px;background:#fafbfc">
        <input id="redeem-shares" inputmode="decimal" placeholder="请输入份额" value="${esc(s.shares)}" style="font-size:25px" />
        <button class="all" data-action="redeem-all">全部</button>
      </div>
      <div class="quick-amounts">${[25, 50, 75].map((pct) => `<button class="chip" data-action="redeem-pct" data-pct="${pct}">${pct}%</button>`).join("")}</div>
      <div style="margin-top:15px;background:#fafbfc;border-radius:12px;padding:10px 12px">
        <div class="sheet-line"><span>赎回净值</span><strong>${money(fund.nav, 4)}</strong></div>
        <div class="sheet-line"><span>赎回费率</span><strong>0.00%</strong></div>
        <div class="sheet-total"><span>预计到账</span><strong id="redeem-total">HKD ${money(estimate)}</strong></div>
      </div>
      <div class="agreement" data-action="toggle-redeem-agree"><span class="check ${s.agreed ? "is-on" : ""}">${icon("check")}</span><span>我已了解赎回申请一经确认不可撤销，资金到账时间以基金公司确认及银行处理时间为准。</span></div>
      <button class="btn btn--primary btn--wide" data-action="confirm-redeem">确认赎回</button>
    </div>`);
  }

  function structuredSheet() {
    const s = state.sheet;
    const p = STRUCTURED_MAP[s.productId];
    if (!p) return "";
    const amount = Number(s.amount) || 0;
    return overlayWrap(`<div class="sheet-grabber"></div>
      <div class="sheet-head"><div><h2>产品认购</h2><p>专业投资者专属 · 非保本浮动收益</p></div><button class="sheet-close" data-action="close-sheet">${icon("close")}</button></div>
      <div class="sheet-fund">${fundBadge({ badge: p.badge, tone: p.tone }, true)}<div><h3>${esc(p.name)}</h3><p>${esc(p.code)} · ${p.term} 个月</p></div><div class="sf-right">年化票息<strong>${p.annual.toFixed(2)}%</strong></div></div>
      <div class="sheet-label"><span>认购金额（${p.currency}）</span><span>起购 <strong>${money(p.min, 0)}</strong></span></div>
      <div class="amount-box" style="border:1px solid var(--line-strong);border-radius:12px;padding:11px 12px;background:#fafbfc">
        <span class="currency-symbol" style="font-size:18px">${p.currency === "USD" ? "$" : "HK$"}</span><input id="structured-amount" inputmode="decimal" placeholder="0.00" value="${esc(s.amount)}" style="font-size:25px" />
      </div>
      <div class="quick-amounts">${[p.min, p.min * 2, p.min * 5].map((n) => `<button class="chip" data-action="structured-quick" data-amount="${n}">${money(n, 0)}</button>`).join("")}</div>
      <div style="margin-top:15px;background:#fafbfc;border-radius:12px;padding:10px 12px">
        <div class="sheet-line"><span>产品期限</span><strong>${p.term} 个月</strong></div>
        <div class="sheet-line"><span>挂钩标的</span><strong>${esc(p.underlying)}</strong></div>
        <div class="sheet-line"><span>认购费率</span><strong>0.00%</strong></div>
        <div class="sheet-total"><span>认购金额</span><strong id="structured-total">${p.currency} ${money(amount)}</strong></div>
      </div>
      <div class="agreement" data-action="toggle-structured-agree"><span class="check ${s.agreed ? "is-on" : ""}">${icon("check")}</span><span>我已阅读并理解产品说明书及风险揭示书，确认自身为专业投资者并能够承担相应风险。</span></div>
      <button class="btn btn--primary btn--wide" data-action="confirm-structured">确认认购</button>
    </div>`);
  }

  function optionsSheet() {
    const s = state.sheet;
    return overlayWrap(`<div class="sheet-grabber"></div>
      <div class="sheet-head"><div><h2>${esc(s.title)}</h2>${s.subtitle ? `<p>${esc(s.subtitle)}</p>` : ""}</div><button class="sheet-close" data-action="close-sheet">${icon("close")}</button></div>
      <div class="option-list">${s.options.map((opt) => `<button class="option-item ${opt.value === s.active ? "is-active" : ""}" data-action="pick-option" data-value="${esc(opt.value)}">${esc(opt.label)}${opt.desc ? `<span class="small muted">${esc(opt.desc)}</span>` : ""}<span class="check ${opt.value === s.active ? "is-on" : ""}">${icon("check")}</span></button>`).join("")}</div>
    </div>`);
  }

  function pinSheet() {
    const p = state.pin;
    return `<div class="overlay"><div class="sheet pin-sheet" data-stop="1">
      <div class="sheet-grabber"></div>
      <div class="sheet-head" style="margin-bottom:2px"><div><h2 style="font-size:16px">${esc(p.title || "请输入交易密码")}</h2><p>${esc(p.subtitle || "用于验证本次交易")}</p></div><button class="sheet-close" data-action="pin-close">${icon("close")}</button></div>
      <div class="pin-dots" id="pin-dots">${Array.from({ length: 6 }).map((_, i) => `<span class="pin-dot ${i < p.digits.length ? "is-filled" : ""}"></span>`).join("")}</div>
      <div class="keypad">
        ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button data-action="pin-key" data-key="${n}">${n}</button>`).join("")}
        <button class="key-empty"></button>
        <button data-action="pin-key" data-key="0">0</button>
        <button class="key-back" data-action="pin-del">${icon("backspace")}</button>
      </div>
      <button class="pin-confirm" data-action="pin-confirm" ${p.digits.length === 6 ? "" : "disabled"}>确认</button>
      <button class="forgot-pin" data-action="toast" data-msg="已发送验证码至 156****1227">忘记密码？</button>
    </div></div>`;
  }

  /* ----------------------------------------------------------
     Page dispatch
     ---------------------------------------------------------- */
  function pageFor(route) {
    switch (route.name) {
      case "home": return pageHome();
      case "news": return route.id ? pageNewsDetail(route) : pageNews();
      case "products": return pageProducts(route);
      case "account": return pageAccount();
      case "mine": return pageMine();
      case "all": return pageAll();
      case "fund": return pageFund(route);
      case "rules": return pageRules(route);
      case "structured": return pageStructured(route);
      case "orders": return pageOrders();
      case "order": return pageOrderDetail(route);
      case "holdings": return pageHoldings();
      case "search": return pageSearch();
      case "deposit": return pageDeposit();
      case "withdraw": return pageWithdraw();
      case "exchange": return pageExchange();
      case "risk": return pageRisk();
      case "professional": return pageProfessional();
      case "analysis": return pageAnalysis();
      case "stock": return pageStock(route);
      case "success": return pageSuccess();
      default: return pageHome();
    }
  }

  function actionbarFor(route) {
    if (route.name === "fund") {
      const fund = getFund(route.id) || FUNDS[0];
      const watched = state.watchlist.includes(fund.id);
      const holding = getHolding(fund.id);
      return `<div class="actionbar">
        <button class="watch-large ${watched ? "is-on" : ""}" data-action="toggle-watch" data-id="${fund.id}">${icon("heart")}<span>${watched ? "已自选" : "自选"}</span></button>
        ${holding ? `<button class="btn secondary" data-action="open-redeem" data-id="${fund.id}">赎回</button>` : ""}
        ${fund.nav ? `<button class="btn btn--primary" data-action="open-buy" data-id="${fund.id}">${holding ? "加仓申购" : "申购"}</button>` : `<button class="btn btn--primary" data-action="toast" data-msg="该基金尚在募集期，暂不支持申购">预约认购</button>`}
      </div>`;
    }
    if (route.name === "structured") {
      const p = STRUCTURED_MAP[route.id] || STRUCTURED[0];
      return `<div class="actionbar">
        <button class="watch-large" data-action="toast" data-msg="产品文件 · PDF 演示">${icon("doc")}<span>文件</span></button>
        <button class="btn btn--primary" data-action="open-structured" data-id="${p.id}">立即认购</button>
      </div>`;
    }
    if (route.name === "stock") {
      const s = getStock(route.id) || MARKET_DATA.hk.indices[0];
      const watched = state.watchlist.includes(s.id);
      return `<div class="actionbar">
        <button class="watch-large ${watched ? "is-on" : ""}" data-action="toggle-watch" data-id="${s.id}">${icon("heart")}<span>${watched ? "已自选" : "自选"}</span></button>
        <button class="btn btn--ghost" style="flex:0 0 95px" data-action="toast" data-msg="模拟卖出 · 演示入口">卖出</button>
        <button class="btn btn--primary" data-action="toast" data-msg="模拟买入 · 演示入口">买入</button>
      </div>`;
    }
    if (route.name === "order") {
      const order = state.orders.find((o) => o.id === route.id);
      if (order && (order.status.includes("待确认") || order.status.includes("已提交"))) {
        return `<div class="actionbar">
          <button class="btn btn--ghost" style="flex:0 0 115px" data-action="cancel-order" data-id="${order.id}">取消订单</button>
          <button class="btn btn--primary" data-action="reorder" data-id="${order.id}">再买一笔</button>
        </div>`;
      }
    }
    return "";
  }

  /* ----------------------------------------------------------
     Render
     ---------------------------------------------------------- */
  let lastRenderKey = "";
  let lastScroll = 0;
  let forceScrollTop = false;
  const app = document.getElementById("app");

  function getActiveRoot() {
    const r = parseRoute();
    if (r.id) return "";
    return ROOT_TABS.some((t) => t.name === r.name) ? r.name : "";
  }

  function render() {
    const route = parseRoute();
    const key = routeKey(route);
    const keepScroll = !forceScrollTop && key === lastRenderKey && !["success"].includes(route.name);
    const oldViewport = document.getElementById("viewport");
    const samePage = Boolean(oldViewport) && key === lastRenderKey;
    const overlayWasOpen = Boolean(document.querySelector(".overlay"));
    if (oldViewport) lastScroll = oldViewport.scrollTop;

    const page = pageFor(route);
    const actionbar = actionbarFor(route);
    const nav = getActiveRoot() ? bottomNav(route.name) : "";
    app.innerHTML = `${statusbar()}
      <div class="viewport" id="viewport">${page}</div>
      ${actionbar}
      ${nav}
      ${renderOverlay()}`;

    lastRenderKey = key;
    forceScrollTop = false;
    const newViewport = document.getElementById("viewport");
    if (newViewport) {
      newViewport.scrollTop = keepScroll ? lastScroll : 0;
    }
    if (route.name === "products") {
      const tabsEl = document.querySelector(".product-tabs");
      const activeTab = tabsEl && tabsEl.querySelector(".product-tab.is-active");
      if (tabsEl && activeTab) {
        const tabsRect = tabsEl.getBoundingClientRect();
        const activeRect = activeTab.getBoundingClientRect();
        const offscreen = activeRect.left < tabsRect.left + 8 || activeRect.right > tabsRect.right - 8;
        if (offscreen) {
          const target = tabsEl.scrollLeft + activeRect.left - tabsRect.left - (tabsEl.clientWidth - activeRect.width) / 2;
          tabsEl.scrollLeft = Math.max(0, target);
        }
      }
    }
    if (samePage) {
      app.querySelector(".page")?.classList.add("no-enter");
    }
    if (overlayWasOpen) {
      const overlay = app.querySelector(".overlay");
      if (overlay) {
        overlay.classList.add("no-enter");
        overlay.querySelector(".sheet")?.classList.add("no-enter");
      }
    }
    if (route.name === "search") {
      requestAnimationFrame(() => {
        const input = document.getElementById("search-input");
        if (input && !input.value) input.focus({ preventScroll: true });
      });
    }
  }

  /* ----------------------------------------------------------
     Navigation / actions
     ---------------------------------------------------------- */
  function openOptions(key, title, options, active) {
    state.sheet = { type: "options", key, title, options, active };
    render();
  }

  function filterOptions(key) {
    if (key === "type") {
      openOptions("fundType", "基金类型", [{ label: "全部类型", value: "all" }, { label: "股票型", value: "股票型" }, { label: "混合型", value: "混合型" }, { label: "货币型", value: "货币型" }], state.fundFilter.type);
    } else if (key === "risk") {
      openOptions("fundRisk", "风险等级", [{ label: "全部风险", value: "all" }, { label: "低风险", value: "低风险" }, { label: "中风险", value: "中风险" }, { label: "中高风险", value: "中高风险" }, { label: "高风险", value: "高风险" }], state.fundFilter.risk);
    } else {
      openOptions("fundMin", "起投金额", [{ label: "全部金额", value: "all" }, { label: "1,000 以下", value: "1000" }, { label: "10,000 以下", value: "10000" }, { label: "50,000 以下", value: "50000" }], state.fundFilter.min);
    }
  }

  function orderFilterOptions(key) {
    if (key === "fund") {
      const ids = [...new Set(state.orders.map((o) => o.fundId))];
      const options = [{ label: "全部基金", value: "all" }].concat(ids.map((id) => ({ label: getFund(id)?.name || state.orders.find((o) => o.fundId === id)?.name || id, value: id })));
      openOptions("orderFund", "选择基金", options, state.orderFilter.fund);
    } else {
      openOptions("orderType", "订单类型", [{ label: "全部类型", value: "all" }, { label: "申购", value: "申购" }, { label: "赎回", value: "赎回" }, { label: "认购", value: "认购" }], state.orderFilter.type);
    }
  }

  function openBuy(fundId) {
    const fund = getFund(fundId);
    if (!fund) return;
    if (!fund.nav) {
      showToast("该基金尚在募集期，暂不支持申购");
      return;
    }
    state.sheet = { type: "buy", fundId, amount: fund.min ? String(fund.min) : "10000", agreed: false };
    render();
  }

  function openRedeem(fundId) {
    const holding = getHolding(fundId);
    if (!holding) {
      showToast("暂无可赎回份额");
      return;
    }
    state.sheet = { type: "redeem", fundId, shares: String(holding.shares), agreed: false };
    render();
  }

  function openStructured(productId) {
    const p = STRUCTURED_MAP[productId];
    if (!p) return;
    state.sheet = { type: "structured", productId, amount: String(p.min), agreed: false };
    render();
  }

  function openPin(title, subtitle, cb) {
    pendingPinAction = cb;
    state.pin = { title, subtitle, digits: "" };
    render();
  }

  function closeOverlay() {
    state.pin = null;
    pendingPinAction = null;
    state.sheet = null;
    render();
  }

  function applyOption(key, value) {
    if (key === "fundType") state.fundFilter.type = value;
    else if (key === "fundRisk") state.fundFilter.risk = value;
    else if (key === "fundMin") state.fundFilter.min = value;
    else if (key === "orderFund") state.orderFilter.fund = value;
    else if (key === "orderType") state.orderFilter.type = value;
    else if (key === "exchangeFrom") state.exchange.from = value;
    else if (key === "exchangeTo") state.exchange.to = value;
    else if (key === "withdrawCurrency") state.withdraw.currency = value;
    state.sheet = null;
    saveState();
    render();
  }

  function createOrder({ fundId, name, code, type, amount, fee = 0, shares = 0, currency = "HKD" }) {
    return {
      id: `ord-${Date.now()}`,
      fundId,
      name,
      code,
      type,
      status: "已下单待确认",
      amount,
      fee,
      shares,
      currency,
      date: nowText(),
      orderNo: makeOrderNo(type === "认购" ? "STR" : "FUND"),
    };
  }

  function confirmBuy() {
    const s = state.sheet;
    if (!s) return;
    const fund = getFund(s.fundId);
    const amount = Number(s.amount);
    if (!amount || amount <= 0) {
      showToast("请输入有效的申购金额");
      return;
    }
    if (fund.min && amount < fund.min) {
      showToast(`最低申购金额为 ${money(fund.min, 0)} ${fund.currency}`);
      return;
    }
    if (!s.agreed) {
      showToast("请先阅读并同意相关协议");
      return;
    }
    state.sheet = null;
    openPin("请输入交易密码", `申购 ${fund.name}`, () => {
      const order = createOrder({
        fundId: fund.id,
        name: fund.name,
        code: fund.code,
        type: "申购",
        amount,
        fee: 0,
        currency: fund.currency,
      });
      state.orders.unshift(order);
      state.successData = {
        kind: "buy",
        title: "申购委托已提交",
        subtitle: "待基金公司确认份额，确认后将更新持仓",
        rows: [
          ["基金名称", fund.name],
          ["申购金额", `${fund.currency} ${money(amount)}`],
          ["预计份额", `${money(amount / fund.nav, 4)} 份`],
          ["订单状态", "已下单待确认"],
          ["订单号", order.orderNo],
        ],
      };
      saveState();
      navigate("#/success");
    });
  }

  function confirmRedeem() {
    const s = state.sheet;
    if (!s) return;
    const fund = getFund(s.fundId);
    const holding = getHolding(s.fundId);
    const shares = Number(s.shares);
    if (!holding || !shares || shares <= 0) {
      showToast("请输入有效的赎回份额");
      return;
    }
    if (shares > holding.shares + 0.000001) {
      showToast("赎回份额不能超过可用份额");
      return;
    }
    if (!s.agreed) {
      showToast("请先确认赎回相关提示");
      return;
    }
    state.sheet = null;
    openPin("请输入交易密码", `赎回 ${fund.name}`, () => {
      const amount = shares * fund.nav;
      const order = createOrder({
        fundId: fund.id,
        name: fund.name,
        code: fund.code,
        type: "赎回",
        amount,
        fee: 0,
        shares,
        currency: fund.currency,
      });
      state.orders.unshift(order);
      holding.shares = Math.max(0, holding.shares - shares);
      if (holding.shares <= 0.0001) {
        state.holdings = state.holdings.filter((h) => h.fundId !== fund.id);
      }
      state.successData = {
        kind: "redeem",
        title: "赎回申请已提交",
        subtitle: "申请已受理，等待基金公司确认",
        rows: [
          ["基金名称", fund.name],
          ["赎回份额", `${money(shares, 4)} 份`],
          ["预计到账", `${fund.currency} ${money(amount)}`],
          ["订单状态", "已提交待确认"],
          ["订单号", order.orderNo],
        ],
      };
      saveState();
      navigate("#/success");
    });
  }

  function confirmStructured() {
    const s = state.sheet;
    if (!s) return;
    const p = STRUCTURED_MAP[s.productId];
    const amount = Number(s.amount);
    if (!p) return;
    if (!amount || amount < p.min) {
      showToast(`认购金额不得低于 ${money(p.min, 0)} ${p.currency}`);
      return;
    }
    if (!s.agreed) {
      showToast("请先阅读并同意产品文件");
      return;
    }
    state.sheet = null;
    openPin("请输入交易密码", `认购 ${p.name}`, () => {
      const order = createOrder({
        fundId: p.id,
        name: p.name,
        code: p.code,
        type: "认购",
        amount,
        fee: 0,
        currency: p.currency,
      });
      state.orders.unshift(order);
      state.successData = {
        kind: "buy",
        title: "认购申请已提交",
        subtitle: "产品额度确认后将通知您完成后续流程",
        rows: [
          ["产品名称", p.name],
          ["认购金额", `${p.currency} ${money(amount)}`],
          ["产品期限", `${p.term} 个月`],
          ["订单状态", "已下单待确认"],
          ["订单号", order.orderNo],
        ],
      };
      saveState();
      navigate("#/success");
    });
  }

  function submitDeposit() {
    const d = state.deposit;
    const amount = Number(d.amount);
    if (!amount || amount < 100) {
      showToast("请输入不低于 100 的入金金额");
      return;
    }
    openPin("请输入交易密码", `存入 ${d.currency} ${money(amount)}`, () => {
      state.successData = {
        kind: "deposit",
        title: "入金凭证已提交",
        subtitle: "银行处理完成后将自动入账",
        rows: [
          ["存入币种", d.currency],
          ["存入金额", `${d.currency} ${money(amount)}`],
          ["收款银行", "汇丰银行（香港）"],
          ["预计到账", "1–2 个工作日"],
          ["状态", "待银行处理"],
        ],
      };
      state.deposit = { step: 1, currency: d.currency, amount: "", bank: "hsbc" };
      saveState();
      navigate("#/success");
    });
  }

  function submitWithdraw() {
    const w = state.withdraw;
    const amount = Number(w.amount);
    if (!amount || amount <= 0) {
      showToast("请输入有效的提款金额");
      return;
    }
    if (amount > 4851219.28) {
      showToast("提款金额不能超过可用余额");
      return;
    }
    openPin("请输入交易密码", `提取 ${w.currency} ${money(amount)}`, () => {
      state.successData = {
        kind: "withdraw",
        title: "提款申请已提交",
        subtitle: "资金将退回至已认证的银行账户",
        rows: [
          ["提款币种", w.currency],
          ["提款金额", `${w.currency} ${money(amount)}`],
          ["收款账户", "中国银行（香港）5424"],
          ["预计到账", "1–2 个工作日"],
          ["状态", "处理中"],
        ],
      };
      state.withdraw.amount = "";
      saveState();
      navigate("#/success");
    });
  }

  function submitExchange() {
    const e = state.exchange;
    const amount = Number(e.amount);
    if (!amount || amount <= 0) {
      showToast("请输入有效的兑换金额");
      return;
    }
    if (e.from === e.to) {
      showToast("请选择不同的兑换币种");
      return;
    }
    const rates = { "HKD-CNY": 0.912, "CNY-HKD": 1.0965, "HKD-USD": 0.1281, "USD-HKD": 7.806, "CNY-USD": 0.1404, "USD-CNY": 7.12 };
    const rate = rates[`${e.from}-${e.to}`] || 1;
    openPin("请输入交易密码", `兑换 ${e.from} ${money(amount)}`, () => {
      state.successData = {
        kind: "exchange",
        title: "兑换委托已提交",
        subtitle: "成交后将更新您的现金余额",
        rows: [
          ["兑换方向", `${e.from} → ${e.to}`],
          ["兑换金额", `${e.from} ${money(amount)}`],
          ["参考汇率", `1 ${e.from} = ${rate} ${e.to}`],
          ["预计所得", `${e.to} ${money(amount * rate)}`],
          ["状态", "处理中"],
        ],
      };
      state.exchange.amount = "";
      saveState();
      navigate("#/success");
    });
  }

  /* ----------------------------------------------------------
     Event handling
     ---------------------------------------------------------- */
  app.addEventListener("click", (event) => {
    if (event.target.classList.contains("overlay")) {
      closeOverlay();
      return;
    }

    const actionEl = event.target.closest("[data-action]");
    const navEl = event.target.closest("[data-nav]");

    // Interactive controls inside a clickable card should win over the card.
    if (!actionEl && navEl) {
      event.preventDefault();
      navigate(navEl.getAttribute("data-nav"));
      return;
    }
    if (!actionEl) return;

    const el = actionEl;
    const action = el.dataset.action;

    const stop = (fn) => {
      event.preventDefault();
      event.stopPropagation();
      fn();
    };

    switch (action) {
      case "back":
        goBack();
        break;
      case "open-search":
        navigate("#/search");
        break;
      case "open-mail":
        showToast("暂无新的消息");
        break;
      case "overlay-close":
        closeOverlay();
        break;
      case "close-sheet":
        closeOverlay();
        break;
      case "toast":
        showToast(el.dataset.msg || "演示入口");
        break;
      case "go-products":
        goProducts(el.dataset.tab);
        break;
      case "toggle-amount":
        state.hideAmounts = !state.hideAmounts;
        saveState();
        render();
        break;
      case "account-tab":
        state.accountTab = el.dataset.tab;
        forceScrollTop = true;
        render();
        break;
      case "toggle-group":
        state.openGroups[el.dataset.key] = !state.openGroups[el.dataset.key];
        saveState();
        render();
        break;
      case "product-tab":
        state.productsTab = el.dataset.tab;
        saveState();
        forceScrollTop = true;
        render();
        break;
      case "news-tab":
        state.newsTab = el.dataset.tab;
        if (el.dataset.tab === "看美股") state.newsFilter = "美股";
        if (el.dataset.tab === "看中国") state.newsFilter = "A股";
        if (el.dataset.tab === "快讯") state.newsFilter = "港股";
        saveState();
        forceScrollTop = true;
        render();
        break;
      case "news-filter":
        state.newsFilter = el.dataset.filter;
        if (["看美股", "看中国", "日历", "自选"].includes(state.newsTab)) state.newsTab = "快讯";
        saveState();
        forceScrollTop = true;
        render();
        break;
      case "fund-tab":
        state.fundDetailTab = el.dataset.tab;
        render();
        break;
      case "fund-period":
        state.fundPeriod = el.dataset.period;
        render();
        break;
      case "toggle-watch":
        toggleWatch(el.dataset.id);
        break;
      case "open-buy":
        openBuy(el.dataset.id);
        break;
      case "open-redeem":
        openRedeem(el.dataset.id);
        break;
      case "open-structured":
        openStructured(el.dataset.id);
        break;
      case "buy-quick":
        state.sheet.amount = el.dataset.amount;
        render();
        break;
      case "structured-quick":
        state.sheet.amount = el.dataset.amount;
        render();
        break;
      case "redeem-pct": {
        const h = getHolding(state.sheet.fundId);
        const pct = Number(el.dataset.pct);
        state.sheet.shares = (h.shares * (pct / 100)).toFixed(4);
        render();
        break;
      }
      case "redeem-all": {
        const h = getHolding(state.sheet.fundId);
        state.sheet.shares = String(h.shares);
        render();
        break;
      }
      case "toggle-agree":
      case "toggle-redeem-agree":
      case "toggle-structured-agree":
        state.sheet.agreed = !state.sheet.agreed;
        el.querySelector(".check")?.classList.toggle("is-on", state.sheet.agreed);
        break;
      case "confirm-buy":
        confirmBuy();
        break;
      case "confirm-redeem":
        confirmRedeem();
        break;
      case "confirm-structured":
        confirmStructured();
        break;
      case "pin-key":
        if (!state.pin) break;
        if (state.pin.digits.length < 6) {
          state.pin.digits += el.dataset.key;
          updatePinUI();
        }
        break;
      case "pin-del":
        if (state.pin) {
          state.pin.digits = state.pin.digits.slice(0, -1);
          updatePinUI();
        }
        break;
      case "pin-confirm": {
        if (!state.pin) break;
        if (state.pin.digits.length !== 6) {
          const dots = document.getElementById("pin-dots");
          if (dots) {
            dots.classList.remove("shake");
            void dots.offsetWidth;
            dots.classList.add("shake");
          }
          showToast("请输入 6 位交易密码");
          break;
        }
        const cb = pendingPinAction;
        state.pin = null;
        pendingPinAction = null;
        if (cb) cb();
        else render();
        break;
      }
      case "pin-close":
        state.pin = null;
        pendingPinAction = null;
        render();
        break;
      case "success-done":
        state.successData = null;
        navigate("#/home");
        break;
      case "filter":
        filterOptions(el.dataset.key);
        break;
      case "order-filter":
        orderFilterOptions(el.dataset.key);
        break;
      case "pick-option":
        applyOption(state.sheet.key, el.dataset.value);
        break;
      case "search-hot": {
        const q = el.dataset.q;
        state.searchQuery = q;
        if (!state.recentSearches.includes(q)) {
          state.recentSearches.unshift(q);
          state.recentSearches = state.recentSearches.slice(0, 5);
        }
        saveState();
        render();
        requestAnimationFrame(() => {
          const input = document.getElementById("search-input");
          if (input) {
            input.value = q;
            input.focus({ preventScroll: true });
            input.setSelectionRange(q.length, q.length);
          }
          const body = document.getElementById("search-body");
          if (body) body.innerHTML = searchBody(q);
        });
        break;
      }
      case "search-clear":
        state.searchQuery = "";
        render();
        requestAnimationFrame(() => document.getElementById("search-input")?.focus({ preventScroll: true }));
        break;
      case "deposit-currency":
        state.deposit.currency = el.dataset.currency;
        saveState();
        render();
        break;
      case "deposit-quick":
        state.deposit.amount = el.dataset.amount;
        saveState();
        render();
        break;
      case "deposit-next": {
        const amt = Number(state.deposit.amount);
        if (!amt || amt < 100) {
          showToast("请输入不低于 100 的入金金额");
          break;
        }
        state.deposit.step = 2;
        saveState();
        render();
        break;
      }
      case "deposit-back":
        state.deposit.step = 1;
        render();
        break;
      case "deposit-submit":
        submitDeposit();
        break;
      case "withdraw-currency":
        state.withdraw.currency = el.dataset.currency;
        saveState();
        render();
        break;
      case "withdraw-quick":
        state.withdraw.amount = el.dataset.amount;
        saveState();
        render();
        break;
      case "withdraw-all":
        state.withdraw.amount = state.withdraw.currency === "HKD" ? "4851219.28" : "100000";
        saveState();
        render();
        break;
      case "withdraw-submit":
        submitWithdraw();
        break;
      case "exchange-pick": {
        const side = el.dataset.side;
        const options = ["HKD", "CNY", "USD"].filter((c) => c !== (side === "from" ? state.exchange.to : state.exchange.from)).map((c) => ({ label: { HKD: "港币 HKD", CNY: "人民币 CNY", USD: "美元 USD" }[c], value: c }));
        openOptions(side === "from" ? "exchangeFrom" : "exchangeTo", side === "from" ? "选择卖出币种" : "选择买入币种", options, side === "from" ? state.exchange.from : state.exchange.to);
        break;
      }
      case "exchange-switch":
        [state.exchange.from, state.exchange.to] = [state.exchange.to, state.exchange.from];
        state.exchange.amount = "";
        saveState();
        render();
        break;
      case "exchange-quick":
        state.exchange.amount = el.dataset.amount;
        saveState();
        render();
        break;
      case "exchange-submit":
        submitExchange();
        break;
      case "risk-start":
        state.risk = { started: true, step: 0, answers: [], done: false };
        saveState();
        render();
        break;
      case "risk-answer": {
        const i = Number(el.dataset.index);
        state.risk.answers[state.risk.step] = i;
        if (state.risk.step >= RISK_QUESTIONS.length - 1) {
          state.risk.done = true;
        } else {
          state.risk.step += 1;
        }
        saveState();
        render();
        break;
      }
      case "risk-reset":
        state.risk = { started: true, step: 0, answers: [], done: false };
        saveState();
        render();
        break;
      case "risk-finish":
        navigate("#/mine");
        break;
      case "reset-demo":
        try { localStorage.removeItem(STORAGE_KEY); } catch { /* noop */ }
        state = cloneDefault();
        state.route = { name: "home", id: null, query: {} };
        history.replaceState({ depth: 1 }, "", "#/home");
        routeStack = [{ name: "home", id: null, query: {} }];
        render();
        showToast("演示数据已重置");
        break;
      case "copy": {
        const text = el.dataset.copy || "";
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(() => showToast("已复制账号")).catch(() => showToast("账号：" + text));
        } else {
          showToast("账号：" + text);
        }
        break;
      }
      case "cancel-order": {
        const id = el.dataset.id;
        const order = state.orders.find((o) => o.id === id);
        if (!order) break;
        order.status = "已撤销";
        saveState();
        render();
        showToast("订单已撤销");
        break;
      }
      case "reorder": {
        const order = state.orders.find((o) => o.id === el.dataset.id);
        if (!order) break;
        if (order.fundId && getFund(order.fundId)) openBuy(order.fundId);
        else if (order.fundId && STRUCTURED_MAP[order.fundId]) openStructured(order.fundId);
        else showToast("请前往产品页重新选择");
        break;
      }
      default:
        break;
    }
  });

  app.addEventListener("input", (event) => {
    const t = event.target;
    if (t.id === "search-input") {
      state.searchQuery = t.value;
      const body = document.getElementById("search-body");
      if (body) body.innerHTML = searchBody(t.value);
    } else if (t.id === "buy-amount") {
      state.sheet.amount = t.value;
      updateBuySheet();
    } else if (t.id === "redeem-shares") {
      state.sheet.shares = t.value;
      updateRedeemSheet();
    } else if (t.id === "structured-amount") {
      state.sheet.amount = t.value;
      const p = STRUCTURED_MAP[state.sheet.productId];
      const total = document.getElementById("structured-total");
      if (total) total.textContent = `${p.currency} ${money(Number(t.value) || 0)}`;
    } else if (t.id === "deposit-amount") {
      state.deposit.amount = t.value;
    } else if (t.id === "withdraw-amount") {
      state.withdraw.amount = t.value;
    } else if (t.id === "exchange-amount") {
      state.exchange.amount = t.value;
      const e = state.exchange;
      const rates = { "HKD-CNY": 0.912, "CNY-HKD": 1.0965, "HKD-USD": 0.1281, "USD-HKD": 7.806, "CNY-USD": 0.1404, "USD-CNY": 7.12 };
      const est = document.getElementById("exchange-estimate");
      if (est) est.textContent = `${e.to} ${money((Number(t.value) || 0) * (rates[`${e.from}-${e.to}`] || 1))}`;
    }
  });

  app.addEventListener("keydown", (event) => {
    if (event.target.id === "search-input" && event.key === "Enter") {
      const q = event.target.value.trim();
      if (q && !state.recentSearches.includes(q)) {
        state.recentSearches.unshift(q);
        state.recentSearches = state.recentSearches.slice(0, 5);
        saveState();
      }
      event.target.blur();
    }
    if (event.target.id === "buy-amount" && event.key === "Enter") {
      event.target.blur();
    }
  });

  function updatePinUI() {
    if (!state.pin) return;
    const dots = document.querySelectorAll(".pin-dot");
    dots.forEach((dot, i) => dot.classList.toggle("is-filled", i < state.pin.digits.length));
    const confirm = document.querySelector(".pin-confirm");
    if (confirm) confirm.disabled = state.pin.digits.length !== 6;
  }

  function updateBuySheet() {
    if (!state.sheet || state.sheet.type !== "buy") return;
    const fund = getFund(state.sheet.fundId);
    const amount = Number(state.sheet.amount) || 0;
    const shares = fund.nav ? amount / fund.nav : 0;
    const sharesEl = document.getElementById("buy-shares");
    const totalEl = document.getElementById("buy-total");
    if (sharesEl) sharesEl.textContent = `${money(shares, 4)} 份`;
    if (totalEl) totalEl.textContent = `HKD ${money(amount)}`;
  }

  function updateRedeemSheet() {
    if (!state.sheet || state.sheet.type !== "redeem") return;
    const fund = getFund(state.sheet.fundId);
    const shares = Number(state.sheet.shares) || 0;
    const totalEl = document.getElementById("redeem-total");
    if (totalEl) totalEl.textContent = `HKD ${money(shares * fund.nav)}`;
  }

  /* ----------------------------------------------------------
     Boot
     ---------------------------------------------------------- */
  try {
    history.replaceState({ depth: 1 }, "", location.hash || "#/home");
  } catch {
    /* file:// previews may restrict history access */
  }
  routeStack = [parseRoute()];
  state.route = { ...routeStack[0] };

  window.addEventListener("popstate", (event) => {
    const r = parseRoute();
    state.route = r;
    const depth = event.state && typeof event.state.depth === "number" ? event.state.depth : 1;
    routeStack = routeStack.slice(0, Math.max(1, depth));
    render();
  });

  // Fallback for environments where history is restricted (e.g. some file:// previews).
  window.addEventListener("hashchange", () => {
    const r = parseRoute();
    if (routeKey(r) !== routeKey(state.route)) {
      state.route = r;
      render();
    }
  });

  render();
})();
